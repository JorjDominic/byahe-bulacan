import { useState, useEffect } from "react";
import { useApp } from "../context/AppContext";
import ROUTES from "../constants/routes";
import SpotCard from "../components/SpotCard";
import { getAllSpots } from "../services/spotService";
import bulacanSeal from "../assets/images/bulacan-seal.jpg";

import hero1 from "../assets/images/hero-1.jpg";
import hero2 from "../assets/images/hero-2.jpg";
import hero3 from "../assets/images/hero-3.jpg";
import hero4 from "../assets/images/hero-4.jpg";
import hero5 from "../assets/images/hero-5.jpg";

const HERO_IMAGES = [hero1, hero2, hero3, hero4, hero5];

const FEATURES = [
  { icon: "🗺️", bg: "#e8f5ee", title: "Official Directory",  desc: "Browse admin-verified tourist spots, historical sites, and local enterprises across all Bulacan municipalities." },
  { icon: "📋", bg: "#fef3dc", title: "Itinerary Builder",   desc: "Add spots to your personal trip planner, set visit times, and get a complete cost estimate for your day." },
  { icon: "⭐", bg: "#e8f0fe", title: "Honest Reviews",      desc: "Rate places you've visited with 1–5 stars and leave tips for future travelers." },
  { icon: "📸", bg: "#fce8f3", title: "Community Feed",      desc: "Share your Bulacan travel stories, photos, and hidden gem discoveries with our growing community." },
];

export default function LandingPage() {
  const { navigate } = useApp();
  const [currentImgIndex, setCurrentImgIndex] = useState(0);
  const [spots,           setSpots]           = useState([]);
  const [nextImgIndex,    setNextImgIndex]     = useState(1);
  const [transitioning,   setTransitioning]    = useState(false);

  useEffect(() => {
    getAllSpots().then((data) => setSpots(data.slice(0, 4)));
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setTransitioning(true);
      setTimeout(() => {
        setCurrentImgIndex((prev) => {
          const next = (prev + 1) % HERO_IMAGES.length;
          setNextImgIndex((next + 1) % HERO_IMAGES.length);
          return next;
        });
        setTransitioning(false);
      }, 800);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div>
      {/* ── Hero Section ───────────────────────────────────── */}
      <div
        className="hero"
        style={{
          position:       "relative",
          minHeight:      "100vh",
          display:        "flex",
          alignItems:     "center",
          justifyContent: "center",
          overflow:       "hidden",
        }}
      >
        {/* Background image — fully visible, not cut */}
        <div
          style={{
            position:   "absolute",
            inset:      0,
            backgroundImage:    "url(" + HERO_IMAGES[currentImgIndex] + ")",
            backgroundSize:     "cover",
            backgroundPosition: "center center",
            backgroundRepeat:   "no-repeat",
            transition:         "opacity 0.8s ease",
            opacity:            transitioning ? 0 : 1,
            zIndex:             0,
          }}
        />

        {/* Dark overlay for text readability */}
        <div style={{
          position:   "absolute",
          inset:      0,
          background: "linear-gradient(135deg, rgba(13,61,39,0.82) 0%, rgba(26,92,60,0.75) 100%)",
          zIndex:     1,
        }} />

        {/* Dot indicators */}
        <div style={{
          position:       "absolute",
          bottom:         24,
          left:           "50%",
          transform:      "translateX(-50%)",
          display:        "flex",
          gap:            "0.5rem",
          zIndex:         3,
        }}>
          {HERO_IMAGES.map((_, i) => (
            <div
              key={i}
              onClick={() => setCurrentImgIndex(i)}
              style={{
                width:        i === currentImgIndex ? 24 : 8,
                height:       8,
                borderRadius: 4,
                background:   i === currentImgIndex ? "#fff" : "rgba(255,255,255,0.4)",
                cursor:       "pointer",
                transition:   "all 0.3s ease",
              }}
            />
          ))}
        </div>

        {/* Hero content */}
        <div style={{
          position:       "relative",
          zIndex:         2,
          textAlign:      "center",
          padding:        "2rem 1.5rem",
          maxWidth:       680,
          margin:         "0 auto",
        }}>
          {/* Bulacan Seal */}
          <div style={{ marginBottom: "1.25rem", display: "flex", justifyContent: "center" }}>
            <div style={{
              position: "relative",
              display:  "inline-block",
            }}>
              <img
                src={bulacanSeal}
                alt="Province of Bulacan Official Seal"
                style={{
                  width:        150,
                  height:       150,
                  borderRadius: "50%",
                  objectFit:    "cover",
                  border:       "3px solid rgba(255,255,255,0.6)",
                  boxShadow:    "0 4px 20px rgba(0,0,0,0.3)",
                  background:   "#fff",
                  display:      "block",
                }}
              />
              {/* Glow ring */}
              <div style={{
                position:     "absolute",
                inset:        -10,
                borderRadius: "50%",
                border:       "2px solid rgba(255,255,255,0.2)",
                pointerEvents: "none",
              }} />
            </div>
          </div>

          {/* Province label */}
          <div style={{
            fontSize:      "0.75rem",
            fontWeight:    600,
            letterSpacing: "0.15em",
            color:         "rgba(255,255,255,0.7)",
            marginBottom:  "0.75rem",
            textTransform: "uppercase",
          }}>
            Province of Bulacan, Philippines
          </div>

          <h1 style={{ color: "#fff", marginBottom: "1rem" }}>
            Discover the Hidden<br />
            <em>Beauty of Bulacan</em>
          </h1>

          <p style={{ color: "rgba(255,255,255,0.88)", marginBottom: "2rem", fontSize: "1.05rem", lineHeight: 1.7 }}>
            Your complete travel companion — browse verified tourist spots, plan your perfect itinerary, and share your adventures with fellow explorers.
          </p>

          <div className="hero-btns">
            <button className="hero-btn-white"   onClick={() => navigate(ROUTES.BROWSE)}>
              Explore Destinations
            </button>
            <button className="hero-btn-outline" onClick={() => navigate(ROUTES.LOGIN)}>
              Create Free Account
            </button>
          </div>
        </div>
      </div>

      {/* ── Features ───────────────────────────────────────── */}
      <div className="features">
        <h2 className="section-title">Everything You Need to Plan Your Trip</h2>
        <p className="section-sub">From browsing to building your perfect Bulacan adventure</p>
        <div className="feature-grid">
          {FEATURES.map((f) => (
            <div className="feature-card" key={f.title}>
              <div className="feature-icon" style={{ background: f.bg }}>{f.icon}</div>
              <h3>{f.title}</h3>
              <p>{f.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* ── Top Destinations ───────────────────────────────── */}
      <div className="spots-preview">
        <h2 className="section-title">Top Destinations</h2>
        <p className="section-sub">Explore Bulacan's most celebrated attractions</p>
        <div className="spots-grid" style={{ maxWidth: 1100, margin: "0 auto" }}>
          {spots.length === 0 ? (
            <p style={{ color: "var(--muted)", gridColumn: "1/-1", textAlign: "center" }}>
              Loading spots...
            </p>
          ) : (
            spots.map((s) => (
              <SpotCard key={s.id} spot={s} onClick={() => navigate(ROUTES.SPOT(s.id))} />
            ))
          )}
        </div>
      </div>

      {/* ── CTA Strip ──────────────────────────────────────── */}
      <div className="cta-strip">
        <img
          src={bulacanSeal}
          alt="Bulacan"
          style={{
            width:        56,
            height:       56,
            borderRadius: "50%",
            objectFit:    "cover",
            border:       "2px solid rgba(255,255,255,0.4)",
            marginBottom: "1rem",
            display:      "block",
            margin:       "0 auto 1rem",
          }}
        />
        <h2>Ready to Explore Bulacan?</h2>
        <p>Join thousands of travelers discovering the province's best-kept secrets.</p>
        <button className="hero-btn-white" onClick={() => navigate(ROUTES.LOGIN)}>
          Get Started — It's Free
        </button>
      </div>

      {/* ── Footer ─────────────────────────────────────────── */}
      <footer className="footer">
        <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "0.6rem", marginBottom: "0.4rem" }}>
          <img
            src={bulacanSeal}
            alt="Bulacan"
            style={{ width: 24, height: 24, borderRadius: "50%", objectFit: "cover" }}
          />
          <span>BiyaheBulacan</span>
        </div>
        © 2026 BiyaheBulacan — Proudly promoting the heritage and beauty of Bulacan Province
      </footer>
    </div>
  );
}