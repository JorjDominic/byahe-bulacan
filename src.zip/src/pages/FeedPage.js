import { useState, useEffect, useRef } from "react";
import { useApp } from "../context/AppContext";
import Avatar from "../components/Avatar";
import {
  getFeedPosts,
  addPost,
  likePost,
  unlikePost,
  getUserLikes,
  getCommentsForPost,
  addComment,
  deleteComment,
} from "../services/spotService";

const TRENDING = [
  "Biak-na-Bato Park",
  "Barasoain Church",
  "Malolos Cathedral",
  "St. John the Baptist",
  "Obando Festival",
];

const EVENTS = [
  { title: "Bocaue Pagoda Festival",  date: "July 2026 · Bocaue"        },
  { title: "Singkaban Festival",      date: "September 2026 · Malolos"  },
  { title: "Obando Fertility Rites",  date: "May 17-19 · Obando"        },
  { title: "Pista ng Biak-na-Bato",   date: "November 2026 · San Miguel" },
];

const MUNICIPALITIES = [
  "Bulacan","Malolos","San Miguel","Balagtas","Plaridel",
  "Angat","Bocaue","Meycauayan","Calumpit","Baliuag",
  "Guiguinto","Bulakan","Obando","Pandi","Marilao",
];

export default function FeedPage() {
  const { userName, userId, navigate } = useApp();

  const [posts,      setPosts]      = useState([]);
  const [newPost,    setNewPost]    = useState("");
  const [likedPosts, setLikedPosts] = useState(new Set());
  const [loading,    setLoading]    = useState(true);
  const [posting,    setPosting]    = useState(false);
  const [tag,        setTag]        = useState("Bulacan");
  const [uploadImg,  setUploadImg]  = useState(null);
  const [previewUrl, setPreviewUrl] = useState("");
  const [uploading,  setUploading]  = useState(false);
  const fileInputRef                = useRef(null);

  const firstName = userName ? userName.split(" ")[0] : "Traveler";
  const initials  = userName
    ? userName.split(" ").map((n) => n[0]).join("").slice(0, 2).toUpperCase()
    : "JD";
  const avatarColors = ["#1a5c3c","#b8760a","#533ab7","#c0392b","#2980b9","#16a085","#8e44ad","#d35400"];
  const avatarBg     = avatarColors[userId?.charCodeAt(0) % avatarColors.length] || "#1a5c3c";

  // ─── Load posts + user likes ──────────────────────────
  useEffect(() => {
    setLoading(true);
    Promise.all([
      getFeedPosts(),
      userId ? getUserLikes(userId) : Promise.resolve([]),
    ]).then(([postsData, userLikedIds]) => {
      setPosts(postsData);
      setLikedPosts(new Set(userLikedIds));
      setLoading(false);
    }).catch(() => setLoading(false));
  }, [userId]);

  // ─── Image pick ───────────────────────────────────────
  const handleImagePick = (file) => {
    if (!file || !file.type.startsWith("image/")) return;
    setUploadImg(file);
    setPreviewUrl(URL.createObjectURL(file));
  };

  const handleRemoveImage = () => {
    setUploadImg(null);
    setPreviewUrl("");
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  // ─── Upload to Cloudinary ─────────────────────────────
  const uploadToCloudinary = async (file) => {
    const CLOUD  = process.env.REACT_APP_CLOUDINARY_CLOUD;
    const PRESET = process.env.REACT_APP_CLOUDINARY_PRESET;
    const fd     = new FormData();
    fd.append("file",          file);
    fd.append("upload_preset", PRESET);
    const res  = await fetch(
      "https://api.cloudinary.com/v1_1/" + CLOUD + "/image/upload",
      { method: "POST", body: fd }
    );
    if (!res.ok) throw new Error("Upload failed");
    const data = await res.json();
    return data.secure_url;
  };

  // ─── Submit post ──────────────────────────────────────
  const handlePost = async () => {
    if (!newPost.trim() || posting || !userId) return;
    setPosting(true);
    try {
      let imageUrl = "";
      if (uploadImg) {
        setUploading(true);
        imageUrl = await uploadToCloudinary(uploadImg);
        setUploading(false);
      }
      const created = await addPost(
        userId, userName || "Traveler", initials,
        avatarBg, newPost.trim(), tag, imageUrl
      );
      setPosts((prev) => [created, ...prev]);
      setNewPost("");
      handleRemoveImage();
    } catch (err) {
      console.error("Post error:", err);
      alert("Failed to post. Please try again.");
    } finally {
      setPosting(false);
      setUploading(false);
    }
  };

  // ─── Like / Unlike ────────────────────────────────────
  const handleLike = async (post) => {
    if (!userId) {
      alert("Please log in to like posts!");
      return;
    }

    const alreadyLiked = likedPosts.has(post.id);

    // Optimistic UI
    setLikedPosts((prev) => {
      const next = new Set(prev);
      alreadyLiked ? next.delete(post.id) : next.add(post.id);
      return next;
    });
    setPosts((prev) => prev.map((p) =>
      p.id === post.id
        ? { ...p, likes: Math.max(0, (p.likes || 0) + (alreadyLiked ? -1 : 1)) }
        : p
    ));

    try {
      alreadyLiked
        ? await unlikePost(post.id, userId)
        : await likePost(post.id, userId);
    } catch (err) {
      // Revert on error
      setLikedPosts((prev) => {
        const next = new Set(prev);
        alreadyLiked ? next.add(post.id) : next.delete(post.id);
        return next;
      });
      setPosts((prev) => prev.map((p) =>
        p.id === post.id
          ? { ...p, likes: Math.max(0, (p.likes || 0) + (alreadyLiked ? 1 : -1)) }
          : p
      ));
    }
  };

  // ─── Share ────────────────────────────────────────────
  const handleShare = (post) => {
    const text = post.name + " on BiyaheBulacan: " + post.text.slice(0, 100);
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text)
        .then(() => alert("✅ Copied to clipboard!"))
        .catch(() => alert("Share: " + text));
    } else {
      alert("Share: " + text);
    }
  };

  // ─── Format time ──────────────────────────────────────
  const formatTime = (post) => {
    if (post.createdAt?.toDate) {
      const d    = post.createdAt.toDate();
      const diff = Date.now() - d.getTime();
      const mins  = Math.floor(diff / 60000);
      const hours = Math.floor(diff / 3600000);
      const days  = Math.floor(diff / 86400000);
      if (mins  <  1) return "Just now";
      if (mins  < 60) return mins  + "m ago";
      if (hours < 24) return hours + "h ago";
      return days + "d ago";
    }
    return post.time || "Just now";
  };

  return (
    <div>
      <div className="browse-header">
        <div className="container">
          <h2 style={{ fontFamily: "var(--font-head)", fontSize: "1.4rem" }}>
            Community Travel Feed
          </h2>
          <p style={{ fontSize: "0.875rem", color: "var(--muted)", marginTop: "0.2rem" }}>
            Stories and tips from fellow Bulacan explorers
          </p>
        </div>
      </div>

      <div className="feed-layout container" style={{ paddingTop: "1.5rem" }}>
        <div>

          {/* ── Composer ──────────────────────────────────── */}
          {userId ? (
            <div className="post-composer">
              <div className="composer-header">
                <Avatar initials={initials} bg={avatarBg} size="sm" />
                <span style={{ fontSize: "0.875rem", color: "var(--muted)" }}>
                  {"Share your Bulacan story, " + firstName + "..."}
                </span>
              </div>
              <textarea
                className="composer-input"
                placeholder="Kumusta ang byahe? Share your experience, tips, or discoveries from Bulacan!"
                value={newPost}
                onChange={(e) => setNewPost(e.target.value)}
                disabled={posting}
              />
              {previewUrl && (
                <div style={{ position: "relative", marginBottom: "0.75rem" }}>
                  <img
                    src={previewUrl}
                    alt="preview"
                    style={{ width: "100%", maxHeight: 240, objectFit: "cover", borderRadius: 8 }}
                  />
                  <button
                    onClick={handleRemoveImage}
                    style={{
                      position: "absolute", top: 8, right: 8,
                      background: "rgba(0,0,0,0.6)", border: "none",
                      borderRadius: "50%", width: 28, height: 28,
                      color: "#fff", cursor: "pointer", fontSize: "0.85rem",
                      display: "flex", alignItems: "center", justifyContent: "center",
                    }}
                  >✕</button>
                </div>
              )}
              <div className="composer-footer">
                <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
                  <button
                    className="upload-btn"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={posting}
                    style={{ display: "flex", alignItems: "center", gap: "0.35rem" }}
                  >
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <rect x="3" y="3" width="18" height="18" rx="2"/>
                      <circle cx="8.5" cy="8.5" r="1.5"/>
                      <polyline points="21 15 16 10 5 21"/>
                    </svg>
                    {uploadImg ? "Change Photo" : "Add Photo"}
                  </button>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    style={{ display: "none" }}
                    onChange={(e) => handleImagePick(e.target.files[0])}
                  />
                  <select
                    value={tag}
                    onChange={(e) => setTag(e.target.value)}
                    style={{ padding: "6px 10px", border: "1.5px solid var(--border)", borderRadius: 6, fontFamily: "var(--font-body)", fontSize: "0.8rem", background: "var(--bg)", cursor: "pointer" }}
                  >
                    {MUNICIPALITIES.map((m) => <option key={m}>{m}</option>)}
                  </select>
                </div>
                <button
                  className="btn btn-pri btn-sm"
                  onClick={handlePost}
                  disabled={!newPost.trim() || posting}
                >
                  {uploading ? "Uploading..." : posting ? "Posting..." : "Post Story"}
                </button>
              </div>
            </div>
          ) : (
            <div style={{
              padding: "1.5rem", background: "var(--bg-secondary)",
              borderRadius: 12, border: "1px solid var(--border)",
              textAlign: "center", marginBottom: "1.5rem",
            }}>
              <div style={{ fontSize: "1.5rem", marginBottom: "0.5rem" }}>📸</div>
              <div style={{ fontWeight: 600, marginBottom: "0.25rem" }}>
                Share your Bulacan adventure
              </div>
              <div style={{ fontSize: "0.875rem", color: "var(--muted)", marginBottom: "1rem" }}>
                Log in to post stories, photos, and tips with the community.
              </div>
              <button className="btn btn-pri btn-sm" onClick={() => navigate("login")}>
                Log In to Post
              </button>
            </div>
          )}

          {/* ── Posts ─────────────────────────────────────── */}
          {loading ? (
            <div style={{ padding: "2rem", textAlign: "center", color: "var(--muted)" }}>
              Loading posts...
            </div>
          ) : posts.length === 0 ? (
            <div style={{ padding: "2rem", textAlign: "center", color: "var(--muted)" }}>
              No posts yet — be the first to share your Bulacan story!
            </div>
          ) : (
            posts.map((post) => (
              <PostCard
                key={post.id}
                post={post}
                userId={userId}
                userName={userName}
                isLiked={likedPosts.has(post.id)}
                onLike={() => handleLike(post)}
                onShare={() => handleShare(post)}
                formatTime={formatTime}
              />
            ))
          )}
        </div>

        {/* ── Sidebar ───────────────────────────────────── */}
        <div>
          <div className="sidebar-card">
            <h4 className="sidebar-h4">Trending Destinations</h4>
            {TRENDING.map((name, i) => (
              <div className="trending-item" key={name}>
                <span className="trending-rank">#{i + 1}</span>
                <span className="trending-name">{name}</span>
              </div>
            ))}
          </div>
          <div className="sidebar-card">
            <h4 className="sidebar-h4">Upcoming in Bulacan</h4>
            {EVENTS.map((e) => (
              <div className="event-item" key={e.title}>
                <div className="event-title">{e.title}</div>
                <div className="event-date">{e.date}</div>
              </div>
            ))}
          </div>
          <div className="sidebar-card">
            <h4 className="sidebar-h4">Community Stats</h4>
            <div className="summary-row">
              <span style={{ fontSize: "0.875rem" }}>Total Posts</span>
              <span style={{ fontSize: "0.875rem", fontWeight: 600 }}>{posts.length}</span>
            </div>
            <div className="summary-row">
              <span style={{ fontSize: "0.875rem" }}>Active Explorers</span>
              <span style={{ fontSize: "0.875rem", fontWeight: 600 }}>
                {new Set(posts.map((p) => p.userId).filter(Boolean)).size || 1}
              </span>
            </div>
            {!userId && (
              <button
                className="btn btn-pri btn-sm"
                style={{ width: "100%", marginTop: "0.75rem" }}
                onClick={() => navigate("login")}
              >
                Join Community
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── PostCard ─────────────────────────────────────────────
function PostCard({ post, userId, userName, isLiked, onLike, onShare, formatTime }) {
  const [showComments,  setShowComments]  = useState(false);
  const [comments,      setComments]      = useState([]);
  const [commentText,   setCommentText]   = useState("");
  const [loadingCmts,   setLoadingCmts]   = useState(false);
  const [submittingCmt, setSubmittingCmt] = useState(false);

  const handleToggleComments = async () => {
    setShowComments((prev) => !prev);
    if (!showComments && comments.length === 0) {
      setLoadingCmts(true);
      try {
        const data = await getCommentsForPost(post.id);
        setComments(data);
      } catch (err) {
        console.error("getComments error:", err);
      } finally {
        setLoadingCmts(false);
      }
    }
  };

  const handleComment = async () => {
    if (!commentText.trim() || submittingCmt || !userId) return;
    setSubmittingCmt(true);
    try {
      const newComment = await addComment(
        post.id, userId, userName || "Traveler", commentText.trim()
      );
      setComments((prev) => [...prev, newComment]);
      setCommentText("");
    } catch (err) {
      console.error("addComment error:", err);
      alert("Failed to post comment. Please try again.");
    } finally {
      setSubmittingCmt(false);
    }
  };

  const handleDeleteComment = async (commentId) => {
    if (!window.confirm("Delete this comment?")) return;
    try {
      await deleteComment(commentId, post.id);
      setComments((prev) => prev.filter((c) => c.id !== commentId));
    } catch (err) {
      console.error("deleteComment error:", err);
    }
  };

  const formatCmtTime = (c) => {
    if (c.createdAt?.toDate) {
      const diff  = Date.now() - c.createdAt.toDate().getTime();
      const mins  = Math.floor(diff / 60000);
      const hours = Math.floor(diff / 3600000);
      if (mins  <  1) return "Just now";
      if (mins  < 60) return mins  + "m ago";
      if (hours < 24) return hours + "h ago";
      return Math.floor(diff / 86400000) + "d ago";
    }
    return "Just now";
  };

  const userInitials = userName
    ? userName.split(" ").map((n) => n[0]).join("").slice(0, 2).toUpperCase()
    : "JD";

  return (
    <div className="feed-post">
      {/* ── Header ──────────────────────────────────────── */}
      <div className="post-header">
        <Avatar initials={post.initials || "??"} bg={post.avatarBg} size="sm" />
        <div>
          <div className="post-name">{post.name}</div>
          <div className="post-time">{formatTime(post)}</div>
        </div>
        <span
          className={"tag tag-" + (post.tagColor || "green")}
          style={{ marginLeft: "auto" }}
        >
          {post.tag}
        </span>
      </div>

      {/* ── Text ────────────────────────────────────────── */}
      <div className="post-text">{post.text}</div>

      {/* ── Image ───────────────────────────────────────── */}
      {post.imageUrl && (
        <div style={{ marginTop: "0.75rem", marginBottom: "0.75rem" }}>
          <img
            src={post.imageUrl}
            alt="post"
            style={{ width: "100%", maxHeight: 320, objectFit: "cover", borderRadius: 10 }}
          />
        </div>
      )}
      {!post.imageUrl && post.hasImg && (
        <div className="post-img" style={{ background: post.imgBg }}>{post.imgEmoji}</div>
      )}

      {/* ── Actions ─────────────────────────────────────── */}
      <div className="post-actions">
        {/* Like */}
        <button
          className="post-action"
          onClick={onLike}
          style={{ color: isLiked ? "#e74c3c" : "var(--muted)" }}
          title={isLiked ? "Unlike" : "Like"}
        >
          <svg
            width="14" height="14" viewBox="0 0 24 24"
            fill={isLiked ? "#e74c3c" : "none"}
            stroke={isLiked ? "#e74c3c" : "currentColor"}
            strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"
            style={{ marginRight: 4, verticalAlign: "middle" }}
          >
            <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
          </svg>
          {post.likes || 0} {(post.likes || 0) === 1 ? "like" : "likes"}
        </button>

        {/* Comment */}
        <button
          className="post-action"
          onClick={handleToggleComments}
          style={{ color: showComments ? "var(--pri)" : "var(--muted)" }}
        >
          <svg
            width="14" height="14" viewBox="0 0 24 24"
            fill="none" stroke="currentColor" strokeWidth="2"
            strokeLinecap="round" strokeLinejoin="round"
            style={{ marginRight: 4, verticalAlign: "middle" }}
          >
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
          </svg>
          {post.comments || 0} {(post.comments || 0) === 1 ? "comment" : "comments"}
        </button>

        {/* Share */}
        <button className="post-action" onClick={onShare}>
          <svg
            width="14" height="14" viewBox="0 0 24 24"
            fill="none" stroke="currentColor" strokeWidth="2"
            strokeLinecap="round" strokeLinejoin="round"
            style={{ marginRight: 4, verticalAlign: "middle" }}
          >
            <circle cx="18" cy="5" r="3"/>
            <circle cx="6" cy="12" r="3"/>
            <circle cx="18" cy="19" r="3"/>
            <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/>
            <line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>
          </svg>
          Share
        </button>
      </div>

      {/* ── Comments ────────────────────────────────────── */}
      {showComments && (
        <div style={{ marginTop: "0.75rem", paddingTop: "0.75rem", borderTop: "1px solid var(--border)" }}>

          {/* Comment input */}
          {userId ? (
            <div style={{ display: "flex", gap: "0.5rem", marginBottom: "0.75rem", alignItems: "center" }}>
              <Avatar initials={userInitials} size="sm" />
              <div style={{ flex: 1, display: "flex", gap: "0.4rem" }}>
                <input
                  type="text"
                  placeholder="Write a comment..."
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleComment()}
                  disabled={submittingCmt}
                  style={{
                    flex:         1,
                    padding:      "0.45rem 0.75rem",
                    border:       "1.5px solid var(--border)",
                    borderRadius: 20,
                    fontFamily:   "var(--font-body)",
                    fontSize:     "0.85rem",
                    background:   "var(--bg-secondary)",
                    outline:      "none",
                  }}
                />
                <button
                  className="btn btn-pri btn-sm"
                  onClick={handleComment}
                  disabled={!commentText.trim() || submittingCmt}
                  style={{ borderRadius: 20, padding: "0.45rem 0.9rem", fontSize: "0.8rem" }}
                >
                  {submittingCmt ? "..." : "Post"}
                </button>
              </div>
            </div>
          ) : (
            <p style={{ fontSize: "0.8rem", color: "var(--muted)", marginBottom: "0.5rem" }}>
              Log in to comment.
            </p>
          )}

          {/* Comments list */}
          {loadingCmts ? (
            <p style={{ fontSize: "0.8rem", color: "var(--muted)" }}>Loading comments...</p>
          ) : comments.length === 0 ? (
            <p style={{ fontSize: "0.8rem", color: "var(--muted)" }}>
              No comments yet. Be the first!
            </p>
          ) : (
            comments.map((c) => (
              <div key={c.id} style={{ display: "flex", gap: "0.5rem", marginBottom: "0.6rem", alignItems: "flex-start" }}>
                <Avatar
                  initials={c.user ? c.user.split(" ").map((n) => n[0]).join("").slice(0, 2).toUpperCase() : "??"}
                  size="sm"
                />
                <div style={{ flex: 1, background: "var(--bg-secondary)", borderRadius: 12, padding: "0.5rem 0.75rem" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <span style={{ fontWeight: 600, fontSize: "0.82rem" }}>{c.user}</span>
                    <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
                      <span style={{ fontSize: "0.72rem", color: "var(--muted)" }}>
                        {formatCmtTime(c)}
                      </span>
                      {c.userId === userId && (
                        <button
                          onClick={() => handleDeleteComment(c.id)}
                          style={{ background: "none", border: "none", cursor: "pointer", color: "var(--muted)", fontSize: "0.75rem", padding: 0 }}
                          title="Delete comment"
                        >✕</button>
                      )}
                    </div>
                  </div>
                  <div style={{ fontSize: "0.85rem", marginTop: "0.15rem" }}>{c.text}</div>
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}