import { useState, useEffect, useRef } from "react";
import { useApp } from "../context/AppContext";
import ROUTES from "../constants/routes";
import { saveItinerary, addPost, addReview } from "../services/spotService";

// ─── PH Time helpers ──────────────────────────────────────
function getPHTime() {
  return new Date(new Date().toLocaleString("en-US", { timeZone: "Asia/Manila" }));
}

function getTodayPH() {
  const ph = getPHTime();
  return ph.getFullYear() + "-" +
    String(ph.getMonth() + 1).padStart(2, "0") + "-" +
    String(ph.getDate()).padStart(2, "0");
}

function timeToMinutes(timeStr) {
  if (!timeStr) return 0;
  const [time, period] = timeStr.split(" ");
  const [h, m]         = time.split(":");
  let hour24           = parseInt(h);
  if (period === "PM" && hour24 !== 12) hour24 += 12;
  if (period === "AM" && hour24 === 12) hour24  = 0;
  return hour24 * 60 + parseInt(m);
}

function minutesToTime(minutes) {
  const h      = Math.floor(minutes / 60);
  const m      = minutes % 60;
  const period = h >= 12 ? "PM" : "AM";
  const hour12 = h > 12 ? h - 12 : h === 0 ? 12 : h;
  return hour12 + ":" + String(m).padStart(2, "0") + " " + period;
}

const ALL_TIMES = [
  "7:00 AM","8:00 AM","9:00 AM","10:00 AM","11:00 AM",
  "12:00 PM","1:00 PM","2:00 PM","3:00 PM","4:00 PM",
  "5:00 PM","6:00 PM",
];

function getAvailableTimes(tripDate, existingStops, currentStopId = null, minGapHrs = 3) {
  const ph         = getPHTime();
  const todayPH    = getTodayPH();
  const isToday    = tripDate === todayPH;
  const curMins    = ph.getHours() * 60 + ph.getMinutes();
  const minGapMins = minGapHrs * 60;
  
  const takenMins  = existingStops
    .filter((s) => s.id !== currentStopId)
    .map((s) => timeToMinutes(s.time));

  return ALL_TIMES.filter((t) => {
    const mins = timeToMinutes(t);
    if (isToday && mins <= curMins) return false;
    for (const taken of takenMins) {
      if (Math.abs(mins - taken) < minGapMins) return false;
    }
    return true;
  });
}

function getNextSuggestedTime(existingStops, tripDate, minGapHrs = 3) {
  const todayPH = getTodayPH();
  if (existingStops.length === 0) {
    if (tripDate === todayPH) {
      const ph       = getPHTime();
      const nextHour = ph.getHours() + 1;
      if (nextHour >= 7 && nextHour <= 18) return minutesToTime(nextHour * 60);
    }
    return "9:00 AM";
  }
  const lastTime  = Math.max(...existingStops.map((s) => timeToMinutes(s.time)));
  const suggested = lastTime + minGapHrs * 60;
  if (suggested > 18 * 60) return null;
  return minutesToTime(suggested);
}

function getTripStatus(tripDate, manualDone) {
  if (manualDone) return "done";
  if (!tripDate)  return "planning";
  const todayPH = getTodayPH();
  if (tripDate === todayPH) return "today";
  if (tripDate  <  todayPH) return "done";
  return "planning";
}


const TRIP_CHECKLIST = [
  { id: "route", label: "Route checked in Google Maps", helper: "Confirm travel time and pin location before leaving." },
  { id: "budget", label: "Budget and entrance fees prepared", helper: "Bring extra cash for food, parking, and pasalubong." },
  { id: "weather", label: "Weather and outfit checked", helper: "Prepare umbrella, water, and comfortable clothes." },
  { id: "contacts", label: "Emergency contacts saved", helper: "Save local emergency numbers and share your itinerary." },
];

function buildReadinessNotes(count, totalFee, municipalities) {
  const notes = [];
  if (count === 0) {
    notes.push("Add at least one destination before finalizing your trip.");
  } else if (count >= 4) {
    notes.push("This is a packed itinerary. Consider increasing the time gap between stops.");
  } else {
    notes.push("Your stop count looks manageable for a Bulacan day trip.");
  }

  if (totalFee === 0) {
    notes.push("Most listed entrance fees are free, but still bring extra cash for food and transport.");
  } else {
    notes.push("Prepare at least ₱" + (totalFee + 300) + " to cover estimated entrance fees and basic allowance.");
  }

  if (municipalities.length > 1) {
    notes.push("You are visiting multiple municipalities: " + municipalities.join(", ") + ". Check route order before leaving.");
  }

  return notes;
}

function StatusBadge({ status }) {
  const config = {
    planning: { bg: "#e8f0fe", color: "#1a73e8", label: "📋 Planning"   },
    today:    { bg: "#fff8e8", color: "#b8760a", label: "🌟 Today!"     },
    done:     { bg: "#e8f5ee", color: "#1a5c3c", label: "✅ Completed"  },
  };
  const c = config[status] || config.planning;
  return (
    <span style={{ background: c.bg, color: c.color, padding: "3px 10px", borderRadius: 20, fontSize: "0.78rem", fontWeight: 600 }}>
      {c.label}
    </span>
  );
}

function parseFee(feeStr) {
  if (!feeStr) return 0;
  const num = parseInt(String(feeStr).replace(/\D/g, ''));
  return isNaN(num) ? 0 : num;
}

// ─── Main Component ───────────────────────────────────────
export default function ItineraryPage() {
  const {
    navigate, userId, userName, showToast,
    getItinerary, updateItineraryMeta, removeFromItinerary, updateStopTime, deleteItinerary
  } = useApp();

  const todayPH        = getTodayPH();
  const [tripDate,     setTripDate]     = useState(todayPH);
  const [saving,       setSaving]       = useState(false);
  const [saved,        setSaved]        = useState(false);
  const [error,        setError]        = useState("");
  const [userLocation, setUserLocation] = useState(null);
  const [editingStopId,setEditingStopId]= useState(null);
  const [manualDone,   setManualDone]   = useState(false);
  const [showReview,   setShowReview]   = useState(false);
  const [showPostFeed, setShowPostFeed] = useState(false);

  // Kukunin natin directly sa Context mo using the tripDate
  const currentItinerary = getItinerary(tripDate);
  const spots            = currentItinerary.spots || [];
  const tripName         = currentItinerary.name || "Bulacan Trip";
  const minGap           = currentItinerary.minGap || 3;
  const count            = spots.length;
  const totalFee         = spots.reduce((sum, spot) => sum + parseFee(spot.fee), 0);
  const checklist        = currentItinerary.checklist || {};
  const checkedCount     = TRIP_CHECKLIST.filter((item) => checklist[item.id]).length;
  const readinessPercent = Math.round((checkedCount / TRIP_CHECKLIST.length) * 100);
  const municipalities   = [...new Set(spots.map((s) => s.municipality).filter(Boolean))];
  const readinessNotes   = buildReadinessNotes(count, totalFee, municipalities);

  const tripStatus    = getTripStatus(tripDate, manualDone);
  const suggestedTime = getNextSuggestedTime(spots, tripDate, minGap);

  // Update status sa context tuwing nagbabago
  useEffect(() => {
    updateItineraryMeta(tripDate, { status: tripStatus });
  }, [tripStatus, tripDate, updateItineraryMeta]);

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => setUserLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
        () => setUserLocation(null)
      );
    }
  }, []);

  const handleSave = async () => {
    if (count === 0) return;
    if (!userId) { navigate(ROUTES.LOGIN); return; }
    setSaving(true);
    setError("");
    try {
      await saveItinerary(userId, tripName, spots);
      setSaved(true);
      showToast("✅ Itinerary saved!");
      setTimeout(() => setSaved(false), 3000);
    } catch (err) {
      setError("Failed to save. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  const handleExportCalendar = () => {
    if (count === 0) { alert("Add spots first!"); return; }
    spots.forEach((spot, index) => {
      const [time, period] = (spot.time || "9:00 AM").split(" ");
      const [h, m]         = time.split(":");
      let hour24           = parseInt(h);
      if (period === "PM" && hour24 !== 12) hour24 += 12;
      if (period === "AM" && hour24 === 12) hour24  = 0;
      const startDate = new Date(tripDate + "T" + String(hour24).padStart(2, "0") + ":" + m + ":00");
      const endDate   = new Date(startDate.getTime() + minGap * 3600000);
      const fmt       = (d) => d.toISOString().replace(/[-:]/g, "").split(".")[0] + "Z";
      const params    = new URLSearchParams({
        action:   "TEMPLATE",
        text:     spot.name + " — " + tripName,
        dates:    fmt(startDate) + "/" + fmt(endDate),
        details:  "Fee: " + spot.fee + "\nPasalubong: " + (spot.pasalubong || "—") + "\nHours: " + (spot.hours || "—") + "\n\nPlanned via BiyaheBulacan",
        location: spot.name + ", " + spot.municipality + ", Bulacan, Philippines",
      });
      setTimeout(() => window.open("https://calendar.google.com/calendar/render?" + params.toString(), "_blank"), index * 800);
    });
  };

  const handleOpenMaps = (spot) => {
    const q = spot.lat && spot.lng
      ? spot.lat + "," + spot.lng
      : encodeURIComponent(spot.name + " " + spot.municipality + " Bulacan");
    window.open("https://www.google.com/maps/search/?api=1&query=" + q, "_blank");
  };

  const getDistance = (lat1, lng1, lat2, lng2) => {
    const R    = 6371;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLng = (lng2 - lng1) * Math.PI / 180;
    const a    = Math.sin(dLat / 2) ** 2 +
                 Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
                 Math.sin(dLng / 2) ** 2;
    return (R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))).toFixed(1);
  };

  const handleEditTime = (stopId, newTime) => {
    const availTimes = getAvailableTimes(tripDate, spots, stopId, minGap);
    
    if (!availTimes.includes(newTime) && newTime !== "") {
        const suggested = getNextSuggestedTime(spots, tripDate, minGap);
        showToast(`❌ Conflict! Time is taken. Suggested: ${suggested}`);
        return;
    }

    updateStopTime(tripDate, stopId, newTime); // Galing mismo sa AppContext mo
    setEditingStopId(null);
    showToast("✅ Arrival time updated!");
  };

  const handleDelete = () => {
    if (!window.confirm(`Delete entire itinerary for ${tripDate}? This cannot be undone.`)) return;
    deleteItinerary(tripDate); // Galing mismo sa AppContext mo
    setManualDone(false);
  };

  const toggleChecklistItem = (itemId) => {
    updateItineraryMeta(tripDate, {
      checklist: {
        ...checklist,
        [itemId]: !checklist[itemId],
      },
    });
  };

  const handleCopyTripSummary = async () => {
    if (count === 0) {
      showToast("Add spots first before copying your trip summary.");
      return;
    }

    const summary = [
      "BiyaheBulacan Trip Plan",
      "Trip: " + tripName,
      "Date: " + tripDate,
      "Stops: " + count,
      "Estimated Entrance Fees: ₱" + totalFee,
      "Readiness: " + readinessPercent + "%",
      "",
      ...sortedItinerary.map((spot, index) => (index + 1) + ". " + spot.time + " - " + spot.name + " (" + spot.municipality + ")"),
      "",
      "Preparation Notes:",
      ...readinessNotes.map((note) => "- " + note),
    ].join("\n");

    try {
      await navigator.clipboard.writeText(summary);
      showToast("✅ Trip summary copied!");
    } catch (err) {
      showToast("Trip summary ready, but clipboard is blocked by the browser.");
    }
  };

  const sortedItinerary = [...spots].sort((a, b) => timeToMinutes(a.time) - timeToMinutes(b.time));

  return (
    <div>
      {/* ── Header ───────────────────────────────────────── */}
      <div className="browse-header">
        <div className="container" style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: "0.5rem" }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: "0.75rem", flexWrap: "wrap" }}>
              <h2 style={{ fontFamily: "var(--font-head)", fontSize: "1.4rem" }}>My Bulacan Itinerary</h2>
              <StatusBadge status={tripStatus} />
            </div>
            <p style={{ fontSize: "0.8rem", color: "var(--muted)", marginTop: "0.2rem" }}>
              Plan your perfect Bulacan adventure
            </p>
          </div>
          <div style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap" }}>
            {tripStatus !== "done" && (
              <button className="btn btn-sec btn-sm" onClick={() => navigate(ROUTES.BROWSE)}>
                + Add More Spots
              </button>
            )}
            {tripStatus === "today" && (
              <button
                className="btn btn-sm"
                style={{ background: "#e8f5ee", color: "#1a5c3c", border: "none", fontWeight: 600 }}
                onClick={() => setManualDone(true)}
              >
                ✅ Mark as Done
              </button>
            )}
            {tripStatus === "done" && (
              <>
                <button className="btn btn-sec btn-sm" onClick={() => setShowReview(true)}>⭐ Review Trip</button>
                <button className="btn btn-pri btn-sm" onClick={() => setShowPostFeed(true)}>📸 Post to Feed</button>
              </>
            )}
          </div>
        </div>
      </div>

      <div className="container" style={{ paddingTop: "1.75rem", paddingBottom: "2rem" }}>
        <div className="itin-builder">

          {/* ── Left ─────────────────────────────────────── */}
          <div>
            {/* Trip meta */}
            <div style={{ background: "var(--bg-secondary)", borderRadius: 12, border: "1px solid var(--border)", padding: "1rem", marginBottom: "1rem" }}>
              <div style={{ display: "flex", gap: "0.75rem", flexWrap: "wrap" }}>
                <div style={{ flex: 2, minWidth: 150 }}>
                  <label style={{ fontSize: "0.72rem", fontWeight: 600, color: "var(--muted)", display: "block", marginBottom: "0.3rem" }}>TRIP NAME</label>
                  <input
                    type="text"
                    value={tripName}
                    onChange={(e) => updateItineraryMeta(tripDate, { name: e.target.value })}
                    disabled={tripStatus === "done"}
                    style={{ width: "100%", padding: "7px 10px", border: "1.5px solid var(--border)", borderRadius: 7, fontFamily: "var(--font-body)", fontSize: "0.875rem", background: "var(--bg)", boxSizing: "border-box" }}
                  />
                </div>
                <div style={{ flex: 1, minWidth: 120 }}>
                  <label style={{ fontSize: "0.72rem", fontWeight: 600, color: "var(--muted)", display: "block", marginBottom: "0.3rem" }}>TRIP DATE</label>
                  <input
                    type="date"
                    value={tripDate}
                    onChange={(e) => setTripDate(e.target.value)}
                    style={{ width: "100%", padding: "7px 10px", border: "1.5px solid var(--border)", borderRadius: 7, fontFamily: "var(--font-body)", fontSize: "0.875rem", background: "var(--bg)", boxSizing: "border-box" }}
                  />
                </div>
                <div style={{ flex: 1, minWidth: 100 }}>
                  <label style={{ fontSize: "0.72rem", fontWeight: 600, color: "var(--muted)", display: "block", marginBottom: "0.3rem" }}>MIN GAP (HRS)</label>
                  <select
                    value={minGap}
                    onChange={(e) => updateItineraryMeta(tripDate, { minGap: Number(e.target.value) })}
                    disabled={tripStatus === "done"}
                    style={{ width: "100%", padding: "7px 10px", border: "1.5px solid var(--border)", borderRadius: 7, fontFamily: "var(--font-body)", fontSize: "0.875rem", background: "var(--bg)", boxSizing: "border-box" }}
                  >
                    {[1,2,3,4,5].map((n) => <option key={n} value={n}>{n} hr{n > 1 ? "s" : ""}</option>)}
                  </select>
                </div>
              </div>
              {tripDate && (
                <div style={{ marginTop: "0.6rem", fontSize: "0.78rem", color: "var(--muted)", display: "flex", alignItems: "center", gap: "0.5rem" }}>
                  📅 {new Date(tripDate + "T00:00:00").toLocaleDateString("en-PH", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}
                  {tripDate === todayPH && (
                    <span style={{ background: "#fff8e8", color: "#b8760a", padding: "1px 8px", borderRadius: 20, fontSize: "0.7rem", fontWeight: 600 }}>Today</span>
                  )}
                </div>
              )}
              {tripStatus !== "done" && count > 0 && suggestedTime && (
                <div style={{ marginTop: "0.4rem", fontSize: "0.75rem", color: "var(--pri)", fontWeight: 500 }}>
                  💡 Next available slot for this day: <strong>{suggestedTime}</strong> ({minGap}hr gap)
                </div>
              )}
            </div>

            {/* Stops */}
            <div className="itin-day-card">
              <div className="itin-day-header">
                <h4>📅 {tripName}</h4>
                <span className="tag tag-green">{count} stops</span>
              </div>

              {count === 0 ? (
                <div style={{ padding: "2rem", textAlign: "center", color: "var(--muted)" }}>
                  <div style={{ fontSize: "2rem", marginBottom: "0.5rem" }}>🗺️</div>
                  <p style={{ marginBottom: "1rem" }}>No spots scheduled for {tripDate} yet.</p>
                  {tripStatus !== "done" && (
                    <button className="btn btn-pri btn-sm" onClick={() => navigate(ROUTES.BROWSE)}>
                      Browse Destinations
                    </button>
                  )}
                </div>
              ) : (
                sortedItinerary.map((s, index) => {
                  const ph      = getPHTime();
                  const curMins = ph.getHours() * 60 + ph.getMinutes();
                  const isPast  = tripDate === todayPH && timeToMinutes(s.time) <= curMins;
                  const isEdit  = editingStopId === s.id;
                  const avail   = getAvailableTimes(tripDate, spots, s.id, minGap);

                  return (
                    <div
                      key={s.id}
                      style={{
                        display:      "flex",
                        alignItems:   "flex-start",
                        gap:          "0.75rem",
                        padding:      "0.875rem 0",
                        borderBottom: index < sortedItinerary.length - 1 ? "1px solid var(--border)" : "none",
                        opacity:      isPast && tripStatus !== "done" ? 0.55 : 1,
                      }}
                    >
                      <div style={{
                        width: 28, height: 28, borderRadius: "50%",
                        background: isPast ? "#aaa" : "var(--pri)",
                        color: "#fff", display: "flex", alignItems: "center",
                        justifyContent: "center", fontSize: "0.75rem",
                        fontWeight: 700, flexShrink: 0, marginTop: 2,
                      }}>
                        {isPast ? "✓" : index + 1}
                      </div>

                      {s.imageUrl ? (
                        <img src={s.imageUrl} alt={s.name} style={{ width: 44, height: 44, borderRadius: 8, objectFit: "cover", flexShrink: 0 }} />
                      ) : (
                        <div style={{ width: 44, height: 44, borderRadius: 8, background: s.bg, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "1.3rem", flexShrink: 0 }}>
                          {s.emoji}
                        </div>
                      )}

                      <div style={{ flex: 1 }}>
                        <div style={{ fontWeight: 700, fontSize: "0.88rem", marginBottom: "0.15rem" }}>{s.name}</div>
                        {isEdit ? (
                          <div style={{ display: "flex", gap: "0.4rem", alignItems: "center", marginBottom: "0.25rem" }}>
                            <select
                              defaultValue={s.time}
                              onChange={(e) => handleEditTime(s.id, e.target.value)}
                              style={{ padding: "3px 6px", border: "1.5px solid var(--border)", borderRadius: 6, fontFamily: "var(--font-body)", fontSize: "0.78rem", background: "var(--bg)" }}
                            >
                              {avail.length === 0
                                ? <option value="">No available times</option>
                                : avail.map((t) => <option key={t} value={t}>{t}</option>)
                              }
                            </select>
                            <button onClick={() => setEditingStopId(null)} style={{ background: "none", border: "none", cursor: "pointer", color: "var(--muted)", fontSize: "0.75rem" }}>Cancel</button>
                          </div>
                        ) : (
                          <div style={{ fontSize: "0.78rem", color: "var(--muted)", display: "flex", alignItems: "center", gap: "0.4rem" }}>
                            🕐 {s.time}
                            {tripStatus !== "done" && (
                              <button onClick={() => setEditingStopId(s.id)} style={{ background: "none", border: "none", cursor: "pointer", color: "var(--pri)", fontSize: "0.7rem", padding: 0, fontFamily: "var(--font-body)" }}>
                                ✏️ Edit
                              </button>
                            )}
                          </div>
                        )}
                        <div style={{ fontSize: "0.75rem", color: "var(--muted)" }}>📍 {s.municipality} · 💰 {s.fee}</div>
                        {userLocation && s.lat && s.lng && (
                          <div style={{ fontSize: "0.72rem", color: "var(--muted)" }}>
                            📏 {getDistance(userLocation.lat, userLocation.lng, s.lat, s.lng)} km from you
                          </div>
                        )}
                        <button onClick={() => handleOpenMaps(s)} style={{ background: "none", border: "none", cursor: "pointer", fontSize: "0.7rem", color: "var(--pri)", padding: 0, fontFamily: "var(--font-body)" }}>
                          🗺️ Open in Google Maps
                        </button>
                      </div>

                      {tripStatus !== "done" && (
                        <button className="itin-remove" onClick={() => removeFromItinerary(tripDate, s.id)}>✕</button>
                      )}
                    </div>
                  );
                })
              )}
            </div>

            {count > 0 && tripStatus !== "done" && (
              <button
                onClick={handleDelete}
                style={{ marginTop: "0.75rem", background: "none", border: "1px solid #fca5a5", color: "#c0392b", borderRadius: 8, padding: "0.5rem 1rem", fontSize: "0.8rem", cursor: "pointer", width: "100%", fontFamily: "var(--font-body)" }}
              >
                🗑️ Delete Itinerary for {tripDate}
              </button>
            )}
          </div>

          {/* ── Right: Summary ────────────────────────────── */}
          <div>
            <div className="summary-card">
              <h3 className="section-h3">Trip Summary</h3>

              {error && (
                <div style={{ background: "#fce8e8", color: "#c0392b", padding: "0.6rem 0.75rem", borderRadius: 7, fontSize: "0.8rem", marginBottom: "0.75rem" }}>
                  {error}
                </div>
              )}

              {count === 0 ? (
                <p style={{ color: "var(--muted)", fontSize: "0.875rem" }}>No spots added yet for this date.</p>
              ) : (
                sortedItinerary.map((s) => (
                  <div className="summary-row" key={s.id}>
                    <span style={{ fontSize: "0.82rem" }}>{s.time} · {s.name}</span>
                    <span style={{ fontSize: "0.82rem", fontWeight: 600 }}>{s.fee}</span>
                  </div>
                ))
              )}

              <div className="summary-total">
                <span>Total ({count} stops)</span>
                <span>₱{totalFee}</span>
              </div>

              <div className="tip-box">
                💡 Entrance fees only. Bring extra for food and pasalubong!
              </div>

              {tripStatus !== "done" ? (
                <>
                  <button
                    className="btn btn-pri"
                    style={{ width: "100%", marginTop: "1rem" }}
                    onClick={handleSave}
                    disabled={saving || count === 0}
                  >
                    {saving ? "Saving..." : saved ? "✅ Saved!" : "💾 Save Itinerary"}
                  </button>
                  <button
                    className="btn btn-sec"
                    style={{ width: "100%", marginTop: "0.75rem", display: "flex", alignItems: "center", justifyContent: "center", gap: "0.4rem" }}
                    onClick={handleExportCalendar}
                    disabled={count === 0}
                  >
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <rect x="3" y="4" width="18" height="18" rx="2"/>
                      <line x1="16" y1="2" x2="16" y2="6"/>
                      <line x1="8"  y1="2" x2="8"  y2="6"/>
                      <line x1="3"  y1="10" x2="21" y2="10"/>
                    </svg>
                    Export to Google Calendar
                  </button>
                </>
              ) : (
                <div style={{ marginTop: "1rem", display: "flex", flexDirection: "column", gap: "0.5rem" }}>
                  <button className="btn btn-sec" style={{ width: "100%" }} onClick={() => setShowReview(true)}>⭐ Review Trip</button>
                  <button className="btn btn-pri" style={{ width: "100%" }} onClick={() => setShowPostFeed(true)}>📸 Post to Feed</button>
                </div>
              )}
            </div>


            {/* Trip readiness */}
            <div className="sidebar-card readiness-card" style={{ marginTop: "1rem" }}>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: "0.75rem", marginBottom: "0.75rem" }}>
                <div>
                  <h4 className="sidebar-h4" style={{ marginBottom: 2 }}>Trip Readiness</h4>
                  <p style={{ fontSize: "0.72rem", color: "var(--muted)", margin: 0 }}>Latest update: smart pre-trip checklist</p>
                </div>
                <div style={{ width: 54, height: 54, borderRadius: "50%", background: readinessPercent === 100 ? "var(--pri-light)" : "#fff8e8", color: readinessPercent === 100 ? "var(--pri)" : "#b8760a", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 800, fontSize: "0.9rem", flexShrink: 0 }}>
                  {readinessPercent}%
                </div>
              </div>

              <div style={{ height: 8, background: "var(--border)", borderRadius: 999, overflow: "hidden", marginBottom: "0.85rem" }}>
                <div style={{ width: readinessPercent + "%", height: "100%", background: readinessPercent === 100 ? "var(--pri)" : "var(--acc)", transition: "width 0.2s" }} />
              </div>

              <div style={{ display: "flex", flexDirection: "column", gap: "0.55rem" }}>
                {TRIP_CHECKLIST.map((item) => (
                  <label key={item.id} style={{ display: "flex", gap: "0.55rem", alignItems: "flex-start", cursor: tripStatus === "done" ? "default" : "pointer" }}>
                    <input
                      type="checkbox"
                      checked={!!checklist[item.id]}
                      onChange={() => toggleChecklistItem(item.id)}
                      disabled={tripStatus === "done"}
                      style={{ marginTop: 3, accentColor: "var(--pri)" }}
                    />
                    <span>
                      <span style={{ display: "block", fontSize: "0.82rem", fontWeight: 700 }}>{item.label}</span>
                      <span style={{ display: "block", fontSize: "0.7rem", color: "var(--muted)", lineHeight: 1.35 }}>{item.helper}</span>
                    </span>
                  </label>
                ))}
              </div>

              <div style={{ marginTop: "0.85rem", padding: "0.75rem", borderRadius: 10, background: "var(--bg-secondary)", border: "1px solid var(--border)" }}>
                <div style={{ fontSize: "0.75rem", fontWeight: 800, color: "var(--muted)", marginBottom: "0.35rem" }}>SMART REMINDERS</div>
                {readinessNotes.map((note) => (
                  <div key={note} style={{ fontSize: "0.75rem", color: "var(--text)", lineHeight: 1.45, marginBottom: "0.28rem" }}>• {note}</div>
                ))}
              </div>

              <button
                className="btn btn-sec"
                style={{ width: "100%", marginTop: "0.75rem" }}
                onClick={handleCopyTripSummary}
                disabled={count === 0}
              >
                📋 Copy Trip Summary
              </button>
            </div>

            {/* Trip info */}
            <div className="sidebar-card" style={{ marginTop: "1rem" }}>
              <h4 className="sidebar-h4">Trip Info</h4>
              {[
                ["Traveler",    userName || "Guest"],
                ["Status",      tripStatus === "done" ? "✅ Completed" : tripStatus === "today" ? "🌟 Today!" : "📋 Planning"],
                ["Total Stops", String(count)],
                ["Est. Fees",   "₱" + totalFee],
                ["Min Gap",     minGap + " hr" + (minGap > 1 ? "s" : "")],
              ].map(([k, v]) => (
                <div className="summary-row" key={k}>
                  <span style={{ fontSize: "0.875rem" }}>{k}</span>
                  <span style={{ fontSize: "0.875rem", fontWeight: 600 }}>{v}</span>
                </div>
              ))}
              {count > 0 && (
                <div className="summary-row">
                  <span style={{ fontSize: "0.875rem" }}>Municipalities</span>
                  <span style={{ fontSize: "0.8rem", fontWeight: 600, textAlign: "right", maxWidth: 160 }}>
                    {[...new Set(spots.map((s) => s.municipality))].join(", ")}
                  </span>
                </div>
              )}
              {userLocation && (
                <div style={{ marginTop: "0.4rem", fontSize: "0.72rem", color: "#2ecc71", display: "flex", alignItems: "center", gap: "0.3rem" }}>
                  <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><polyline points="20 6 9 17 4 12"/></svg>
                  Location detected
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* ── Modals ───────────────────────────────────────── */}
      {showReview && (
        <ReviewModal
          itinerary={spots}
          tripName={tripName}
          userId={userId}
          userName={userName}
          onClose={() => setShowReview(false)}
          showToast={showToast}
        />
      )}
      {showPostFeed && (
        <PostTripModal
          itinerary={spots}
          tripName={tripName}
          tripDate={tripDate}
          totalFee={totalFee}
          userId={userId}
          userName={userName}
          onClose={() => setShowPostFeed(false)}
          navigate={navigate}
          showToast={showToast}
        />
      )}
    </div>
  );
}

// ─── Review Modal ─────────────────────────────────────────
function ReviewModal({ itinerary, tripName, userId, userName, onClose, showToast }) {
  const [activeTab,    setActiveTab]    = useState("overall");
  const [overallStars, setOverallStars] = useState(0);
  const [overallText,  setOverallText]  = useState("");
  const [spotReviews,  setSpotReviews]  = useState(() =>
    Object.fromEntries(itinerary.map((s) => [s.id, { stars: 0, text: "" }]))
  );
  const [submitting, setSubmitting] = useState(false);

  const handleSubmitOverall = async () => {
    if (overallStars === 0 || !overallText.trim()) return;
    setSubmitting(true);
    try {
      if (itinerary[0]) {
        await addReview(itinerary[0].id, userId, userName, overallStars, "Trip review for " + tripName + ": " + overallText.trim());
      }
      showToast("✅ Trip review posted!");
      onClose();
    } catch (err) {
      alert("Failed to post review.");
    } finally {
      setSubmitting(false);
    }
  };

  const handleSubmitPerSpot = async () => {
    setSubmitting(true);
    try {
      for (const spot of itinerary) {
        const r = spotReviews[spot.id];
        if (r?.stars > 0 && r?.text?.trim()) {
          await addReview(spot.id, userId, userName, r.stars, r.text.trim());
        }
      }
      showToast("✅ Reviews posted!");
      onClose();
    } catch (err) {
      alert("Failed to post reviews.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.55)", zIndex: 1000, display: "flex", alignItems: "center", justifyContent: "center", padding: "1rem" }}>
      <div style={{ background: "var(--bg)", borderRadius: 16, padding: "1.5rem", maxWidth: 520, width: "100%", maxHeight: "85vh", overflowY: "auto" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "1rem" }}>
          <h3 style={{ margin: 0 }}>⭐ Review Your Trip</h3>
          <button onClick={onClose} style={{ background: "none", border: "none", cursor: "pointer", fontSize: "1.2rem", color: "var(--muted)" }}>✕</button>
        </div>

        <div style={{ display: "flex", gap: "0.5rem", marginBottom: "1rem" }}>
          {["overall", "per-spot"].map((t) => (
            <button
              key={t}
              onClick={() => setActiveTab(t)}
              style={{
                flex: 1, padding: "0.5rem", borderRadius: 8,
                border: "1.5px solid var(--border)",
                background: activeTab === t ? "var(--pri)" : "transparent",
                color: activeTab === t ? "#fff" : "var(--muted)",
                cursor: "pointer", fontFamily: "var(--font-body)",
                fontSize: "0.85rem", fontWeight: 600,
              }}
            >
              {t === "overall" ? "📝 Overall Trip" : "📍 Per Spot"}
            </button>
          ))}
        </div>

        {activeTab === "overall" ? (
          <>
            <label style={{ fontSize: "0.8rem", fontWeight: 600, display: "block", marginBottom: "0.5rem" }}>
              Rate your overall trip to {tripName}
            </label>
            <div style={{ display: "flex", gap: "0.25rem", marginBottom: "0.75rem" }}>
              {[1,2,3,4,5].map((n) => (
                <span key={n} onClick={() => setOverallStars(n)} style={{ fontSize: "1.8rem", cursor: "pointer", color: n <= overallStars ? "#f59e0b" : "#d1d5db" }}>★</span>
              ))}
            </div>
            <textarea
              placeholder={"How was your trip to " + tripName + "? Share your experience..."}
              value={overallText}
              onChange={(e) => setOverallText(e.target.value)}
              style={{ width: "100%", padding: "0.75rem", border: "1.5px solid var(--border)", borderRadius: 8, fontFamily: "var(--font-body)", fontSize: "0.875rem", background: "var(--bg)", minHeight: 100, resize: "vertical", boxSizing: "border-box", marginBottom: "0.75rem" }}
            />
            <button
              className="btn btn-pri"
              style={{ width: "100%" }}
              onClick={handleSubmitOverall}
              disabled={submitting || overallStars === 0 || !overallText.trim()}
            >
              {submitting ? "Posting..." : "Post Trip Review"}
            </button>
          </>
        ) : (
          <>
            {itinerary.map((spot) => (
              <div key={spot.id} style={{ marginBottom: "1rem", padding: "0.75rem", background: "var(--bg-secondary)", borderRadius: 10 }}>
                <div style={{ display: "flex", alignItems: "center", gap: "0.5rem", marginBottom: "0.5rem" }}>
                  {spot.imageUrl ? (
                    <img src={spot.imageUrl} alt={spot.name} style={{ width: 36, height: 36, borderRadius: 6, objectFit: "cover" }} />
                  ) : (
                    <div style={{ width: 36, height: 36, borderRadius: 6, background: spot.bg, display: "flex", alignItems: "center", justifyContent: "center" }}>{spot.emoji}</div>
                  )}
                  <div>
                    <div style={{ fontWeight: 700, fontSize: "0.85rem" }}>{spot.name}</div>
                    <div style={{ fontSize: "0.72rem", color: "var(--muted)" }}>{spot.municipality}</div>
                  </div>
                </div>
                <div style={{ display: "flex", gap: "0.15rem", marginBottom: "0.4rem" }}>
                  {[1,2,3,4,5].map((n) => (
                    <span
                      key={n}
                      onClick={() => setSpotReviews((prev) => ({ ...prev, [spot.id]: { ...prev[spot.id], stars: n } }))}
                      style={{ fontSize: "1.3rem", cursor: "pointer", color: n <= (spotReviews[spot.id]?.stars || 0) ? "#f59e0b" : "#d1d5db" }}
                    >★</span>
                  ))}
                </div>
                <textarea
                  placeholder={"How was " + spot.name + "?"}
                  value={spotReviews[spot.id]?.text || ""}
                  onChange={(e) => setSpotReviews((prev) => ({ ...prev, [spot.id]: { ...prev[spot.id], text: e.target.value } }))}
                  style={{ width: "100%", padding: "0.5rem", border: "1.5px solid var(--border)", borderRadius: 7, fontFamily: "var(--font-body)", fontSize: "0.8rem", background: "var(--bg)", minHeight: 60, resize: "vertical", boxSizing: "border-box" }}
                />
              </div>
            ))}
            <button
              className="btn btn-pri"
              style={{ width: "100%" }}
              onClick={handleSubmitPerSpot}
              disabled={submitting}
            >
              {submitting ? "Posting..." : "Post All Reviews"}
            </button>
          </>
        )}
      </div>
    </div>
  );
}

// ─── Post Trip Modal ──────────────────────────────────────
function PostTripModal({ itinerary, tripName, tripDate, totalFee, userId, userName, onClose, navigate, showToast }) {
  const [postText,   setPostText]   = useState(
    "Just finished my Bulacan trip — " + tripName + "! Visited " +
    itinerary.length + " amazing spots. Total entrance fees: ₱" + totalFee +
    ". Highly recommend! 🗺️\n\nSpots visited: " +
    itinerary.map((s) => s.name).join(", ")
  );
  const [tag,        setTag]        = useState("Bulacan");
  const [imageUrl,   setImageUrl]   = useState("");
  const [previewUrl, setPreviewUrl] = useState("");
  const [uploading,  setUploading]  = useState(false);
  const [posting,    setPosting]    = useState(false);
  const fileRef                     = useRef(null);

  const initials     = userName ? userName.split(" ").map((n) => n[0]).join("").slice(0, 2).toUpperCase() : "JD";
  const avatarColors = ["#1a5c3c","#b8760a","#533ab7","#c0392b","#2980b9"];
  const avatarBg     = avatarColors[userId?.charCodeAt(0) % avatarColors.length] || "#1a5c3c";

  const handleImagePick = async (file) => {
    if (!file || !file.type.startsWith("image/")) return;
    setPreviewUrl(URL.createObjectURL(file));
    setUploading(true);
    try {
      const CLOUD  = process.env.REACT_APP_CLOUDINARY_CLOUD;
      const PRESET = process.env.REACT_APP_CLOUDINARY_PRESET;
      const fd     = new FormData();
      fd.append("file", file);
      fd.append("upload_preset", PRESET);
      const res  = await fetch("https://api.cloudinary.com/v1_1/" + CLOUD + "/image/upload", { method: "POST", body: fd });
      const data = await res.json();
      setImageUrl(data.secure_url);
    } catch (err) {
      alert("Image upload failed.");
    } finally {
      setUploading(false);
    }
  };

  const handlePost = async () => {
    if (!postText.trim() || posting) return;
    setPosting(true);
    try {
      await addPost(userId, userName || "Traveler", initials, avatarBg, postText.trim(), tag, imageUrl);
      showToast("✅ Trip posted to community feed!");
      onClose();
      navigate(ROUTES.FEED);
    } catch (err) {
      console.error("Post error:", err);
      alert("Failed to post. Please try again.");
    } finally {
      setPosting(false);
    }
  };

  const MUNICIPALITIES = [
    "Bulacan","Malolos","San Miguel","Balagtas","Angat",
    "Bocaue","Calumpit","Baliuag","Obando","Guiguinto",
  ];

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.55)", zIndex: 1000, display: "flex", alignItems: "center", justifyContent: "center", padding: "1rem" }}>
      <div style={{ background: "var(--bg)", borderRadius: 16, padding: "1.5rem", maxWidth: 480, width: "100%", maxHeight: "85vh", overflowY: "auto" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "1rem" }}>
          <h3 style={{ margin: 0 }}>📸 Post Trip to Community</h3>
          <button onClick={onClose} style={{ background: "none", border: "none", cursor: "pointer", fontSize: "1.2rem", color: "var(--muted)" }}>✕</button>
        </div>

        {/* Spots visited */}
        <div style={{ display: "flex", flexWrap: "wrap", gap: "0.4rem", marginBottom: "0.75rem" }}>
          {itinerary.slice(0, 5).map((s) => (
            <span key={s.id} style={{ background: "var(--bg-secondary)", border: "1px solid var(--border)", borderRadius: 20, padding: "2px 10px", fontSize: "0.75rem" }}>
              {s.emoji} {s.name}
            </span>
          ))}
          {itinerary.length > 5 && (
            <span style={{ background: "var(--bg-secondary)", border: "1px solid var(--border)", borderRadius: 20, padding: "2px 10px", fontSize: "0.75rem" }}>
              +{itinerary.length - 5} more
            </span>
          )}
        </div>

        {/* Text */}
        <textarea
          value={postText}
          onChange={(e) => setPostText(e.target.value)}
          style={{ width: "100%", padding: "0.75rem", border: "1.5px solid var(--border)", borderRadius: 8, fontFamily: "var(--font-body)", fontSize: "0.875rem", background: "var(--bg)", minHeight: 120, resize: "vertical", marginBottom: "0.75rem", boxSizing: "border-box" }}
        />

        {/* Image preview */}
        {previewUrl && (
          <div style={{ position: "relative", marginBottom: "0.75rem" }}>
            <img src={previewUrl} alt="preview" style={{ width: "100%", maxHeight: 200, objectFit: "cover", borderRadius: 8 }} />
            <button
              onClick={() => { setPreviewUrl(""); setImageUrl(""); }}
              style={{ position: "absolute", top: 8, right: 8, background: "rgba(0,0,0,0.6)", border: "none", borderRadius: "50%", width: 26, height: 26, color: "#fff", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.8rem" }}
            >✕</button>
          </div>
        )}

        <div style={{ display: "flex", gap: "0.5rem", marginBottom: "0.75rem", alignItems: "center" }}>
          <button
            className="upload-btn"
            onClick={() => fileRef.current?.click()}
            disabled={uploading}
            style={{ display: "flex", alignItems: "center", gap: "0.3rem", fontSize: "0.8rem" }}
          >
            {uploading ? "Uploading..." : "📷 Add Photo"}
          </button>
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            style={{ display: "none" }}
            onChange={(e) => handleImagePick(e.target.files[0])}
          />
          <select
            value={tag}
            onChange={(e) => setTag(e.target.value)}
            style={{ padding: "6px 10px", border: "1.5px solid var(--border)", borderRadius: 6, fontFamily: "var(--font-body)", fontSize: "0.8rem", background: "var(--bg)" }}
          >
            {MUNICIPALITIES.map((m) => <option key={m}>{m}</option>)}
          </select>
        </div>

        <button
          className="btn btn-pri"
          style={{ width: "100%" }}
          onClick={handlePost}
          disabled={!postText.trim() || posting || uploading}
        >
          {posting ? "Posting..." : "🚀 Post to Community Feed"}
        </button>
      </div>
    </div>
  );
}