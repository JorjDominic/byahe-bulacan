import { useState, useEffect } from "react";
import { useApp } from "../context/AppContext";
import ROUTES from "../constants/routes";
import bulacanSeal from "../assets/images/bulacan-seal.jpg";
import { getAllSpots } from "../services/spotService";

// Firebase imports for the success updater
import { doc, updateDoc } from "firebase/firestore";
import { db } from "../services/firebase";

// Helpers
function getPHTime() {
  return new Date(new Date().toLocaleString("en-US", { timeZone: "Asia/Manila" }));
}

function getTodayPH() {
  const ph = getPHTime();
  return ph.getFullYear() + "-" +
    String(ph.getMonth() + 1).padStart(2, "0") + "-" +
    String(ph.getDate()).padStart(2, "0");
}

function parseFee(feeStr) {
  if (!feeStr) return 0;
  const num = parseInt(String(feeStr).replace(/\D/g, ''));
  return isNaN(num) ? 0 : num;
}

export default function DashboardPage() {
  const { userName, userId, navigate, itineraries = {}, itineraryDates = [], getItinerary, isPremium, setPremium, showToast } = useApp();
  const [recommended, setRecommended]  = useState([]);
  const [reviewCount, setReviewCount]  = useState(0); 
  const firstName = userName ? userName.split(" ")[0] : "Traveler";

  // --- SUCCESS REDIRECT HANDLER ---
  useEffect(() => {
    // Check the URL for the PayMongo success parameter
    const params = new URLSearchParams(window.location.search);
    
    if (params.get("payment") === "success" && userId) {
      // 1. Update the database directly from the frontend
      updateDoc(doc(db, "users", userId), { 
        isPremium: true,
        premiumDate: new Date().toISOString()
      }).then(() => {
        // 2. Update global state and notify user
        setPremium(true);
        showToast("💎 Payment Successful! You are now a Premium member.");
        
        // 3. Clean up the URL so the parameter disappears
        window.history.replaceState({}, document.title, "/");
      }).catch(err => {
        console.error("Failed to apply premium upgrade:", err);
      });
    } else if (params.get("payment") === "cancelled") {
      showToast("❌ Payment was cancelled.");
      window.history.replaceState({}, document.title, "/");
    }
  }, [userId, setPremium, showToast]);

  useEffect(() => {
    getAllSpots().then((data) => {
      setRecommended(data.slice(0, 3));
      
      let myReviews = 0;
      data.forEach((spot) => {
        if (spot.reviews && Array.isArray(spot.reviews)) {
          myReviews += spot.reviews.filter((r) => r.userId === userId).length;
        } 
        else if (spot.reviews && typeof spot.reviews === 'object') {
          Object.values(spot.reviews).forEach((r) => {
            if (r.userId === userId) myReviews++;
          });
        }
      });
      setReviewCount(myReviews);
    });
  }, [userId]);

  // Dashboard Logic: Calculate Stats & Upcoming
  const todayPH = getTodayPH();
  const futureDates = itineraryDates.filter(date => date >= todayPH).sort();
  const upcomingDate = futureDates.length > 0 ? futureDates[0] : null;
  const upcomingTrip = upcomingDate ? getItinerary(upcomingDate) : null;
  const upcomingSpots = upcomingTrip ? upcomingTrip.spots || [] : [];
  const upcomingCount = upcomingSpots.length;

  let totalSpots = 0;
  let totalFee = 0;
  Object.values(itineraries).forEach(trip => {
    if (trip.spots) {
      totalSpots += trip.spots.length;
      totalFee += trip.spots.reduce((sum, spot) => sum + parseFee(spot.fee), 0);
    }
  });

  return (
    <div>
      {/* Dashboard Header */}
      <div className="dash-header">
        <div className="dash-header-inner">
          <div style={{ display: "flex", alignItems: "center", gap: "0.75rem" }}>
            <img
              src={bulacanSeal}
              alt="Bulacan"
              style={{
                width:        50, 
                height:       50, 
                borderRadius: "50%",
                objectFit:    "cover",
                border:       "2px solid rgba(255,255,255,0.4)",
                flexShrink:   0,
              }}
            />
            <div>
              <h2>Good morning, {firstName}! 👋</h2>
              <p className="dash-sub">Ready for your next Bulacan adventure?</p>
            </div>
          </div>
          <button className="btn btn-pri btn-sm" onClick={() => navigate(ROUTES.BROWSE)}>
            + Explore Spots
          </button>
        </div>
      </div>

      <div className="container" style={{ paddingTop: "1.75rem" }}>
        {/* Stats */}
        <div className="stats-row">
          <div className="stat-card">
            <div className="stat-lbl">Active Itineraries</div>
            <div className="stat-val">{itineraryDates.length}</div>
            <div className="stat-sub" style={{ color: isPremium ? "var(--pri)" : "var(--muted)", fontWeight: isPremium ? 600 : 400 }}>
              {isPremium ? "Unlimited unlocked 💎" : "1 trip limit (Free)"}
            </div>
          </div>
          <div className="stat-card">
            <div className="stat-lbl">Spots Saved</div>
            <div className="stat-val">{totalSpots}</div>
            <div className="stat-sub">across all trips</div>
          </div>
          <div className="stat-card">
            <div className="stat-lbl">Total Trip Cost</div>
            <div className="stat-val">₱{totalFee}</div>
            <div className="stat-sub">entrance fees estimated</div>
          </div>
        </div>

        {/* Itinerary Preview */}
        <div className="section-head">
          <h3>My Upcoming Itinerary</h3>
          <button className="btn btn-sec btn-sm" onClick={() => navigate(ROUTES.ITINERARY)}>
            View Full ➔
          </button>
        </div>
        
        <div className="itinerary-card">
          <div className="itin-card-header">
            <h4>📍 {upcomingTrip ? upcomingTrip.name : "Bulacan Day Trip"} {upcomingDate ? `(${upcomingDate})` : ""}</h4>
            <span className="tag tag-green">{upcomingCount} stops</span>
          </div>

          {upcomingCount === 0 ? (
            <p className="empty-msg">
              No upcoming spots.{" "}
              <span className="link-text" onClick={() => navigate(ROUTES.BROWSE)}>
                Browse destinations ➔
              </span>
            </p>
          ) : (
            upcomingSpots.slice(0, 4).map((s) => (
              <div className="itin-stop" key={s.id}>
                <div className="itin-time">{s.time}</div>
                <div className="itin-name">{s.name}</div>
                <div className="itin-fee">{s.fee}</div>
              </div>
            ))
          )}
        </div>

        {/* Recommended */}
        <div className="section-head" style={{ marginTop: "1.75rem" }}>
          <h3>Recommended For You</h3>
          <button className="btn btn-sec btn-sm" onClick={() => navigate(ROUTES.BROWSE)}>
            See All ➔
          </button>
        </div>
        <div className="mini-grid">
          {recommended.map((s) => (
            <div className="mini-spot" key={s.id} onClick={() => navigate(ROUTES.SPOT(s.id))}>
              {s.imageUrl ? (
                <img
                  src={s.imageUrl}
                  alt={s.name}
                  style={{ width: "100%", height: "100%", objectFit: "cover", borderRadius: "8px 8px 0 0" }}
                  className="mini-spot-img"
                />
              ) : (
                <div className="mini-spot-img" style={{ background: s.bg }}>{s.emoji}</div>
              )}
              <div className="mini-spot-body">
                <h4>{s.name}</h4>
                <p>{s.municipality} • {s.fee}</p>
              </div>
            </div>
          ))}
          <div className="mini-spot" onClick={() => navigate(ROUTES.BROWSE)}>
            <div className="mini-spot-img" style={{ background: "#f7f8f5", fontSize: "1.2rem", color: "var(--muted)" }}>
              +
            </div>
            <div className="mini-spot-body">
              <h4>Browse All Spots</h4>
              <p>15+ destinations</p>
            </div>
          </div>
        </div>

        {/* Quick Links */}
        <div style={{
          marginTop:    "1.75rem",
          padding:      "1.25rem",
          background:   "var(--bg-secondary)",
          borderRadius: 12,
          border:       "1px solid var(--border)",
          display:      "flex",
          gap:          "0.75rem",
          flexWrap:     "wrap",
        }}>
          <div style={{ fontSize: "0.85rem", fontWeight: 600, color: "var(--muted)", width: "100%", marginBottom: "0.25rem" }}>
            QUICK ACTIONS
          </div>
          <button className="btn btn-sec btn-sm" onClick={() => navigate(ROUTES.ITINERARY)}>
            📅 My Itinerary
          </button>
          <button className="btn btn-sec btn-sm" onClick={() => navigate(ROUTES.FEED)}>
            📸 Community Feed
          </button>
          <button className="btn btn-sec btn-sm" onClick={() => navigate(ROUTES.BROWSE)}>
            🗺️ Explore Spots
          </button>
        </div>
      </div>
    </div>
  );
}