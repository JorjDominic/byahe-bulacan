import { useState, useEffect, useRef } from "react";
import { useAuth } from "../hooks/useAuth";
import { useApp } from "../context/AppContext";
import {
  getAllSpots,
  addSpot,
  updateSpot,
  deleteSpot,
} from "../services/spotService";
import { uploadImage } from "../services/cloudinaryService";
import bulacanSeal from "../assets/images/bulacan-seal.jpg";

const MUNICIPALITIES = [
  "Malolos","San Miguel","Balagtas","Plaridel","Angat","Bocaue",
  "Meycauayan","Calumpit","Baliuag","Guiguinto","Bulakan","Bustos",
  "Hagonoy","Marilao","Norzagaray","Obando","Pandi","Paombong",
  "Pulilan","San Ildefonso","San Jose del Monte","San Rafael",
  "Santa Maria","Dona Remedios Trinidad",
];

const CATEGORIES = [
  "Historical Site","Heritage Site","Ecological Site",
  "Religious Site","Local Enterprise","Other",
];

const BG_OPTIONS = [
  { label: "Green",  value: "#e8f5ee" },
  { label: "Amber",  value: "#fef3dc" },
  { label: "Blue",   value: "#e8f0fe" },
  { label: "Pink",   value: "#fce8f3" },
  { label: "Teal",   value: "#e8f9f0" },
  { label: "Purple", value: "#f5eefe" },
  { label: "Red",    value: "#fce8e8" },
  { label: "Gray",   value: "#f0f0f0" },
];

const EMPTY_FORM = {
  name: "", municipality: "", category: "", fee: "",
  pasalubong: "", hours: "", desc: "", badge: "",
  emoji: "📍", bg: "#e8f5ee", lat: "", lng: "",
  imageUrl: "", mapsLink: "",
};

const INITIAL_FLAGGED = [
  { id: 1, type: "Post",   user: "unknown_user99", label: "Spam", text: '"FAKE SPOT! Scam! Don\'t go here!"' },
  { id: 2, type: "Review", user: "user#1042",      label: "Fake", text: '"★☆☆☆☆ Worst place ever." (multiple reports)' },
];

const SAMPLE_USERS = [
  { name: "Maria Santos",   email: "maria.s@gmail.com",  joined: "Jan 2026", reviews: 14, status: "active"  },
  { name: "Carlo Reyes",    email: "carlo.r@gmail.com",  joined: "Feb 2026", reviews: 7,  status: "active"  },
  { name: "Ana Pascual",    email: "ana.p@yahoo.com",    joined: "Mar 2026", reviews: 22, status: "active"  },
  { name: "unknown_user99", email: "unknown@temp.com",   joined: "Apr 2026", reviews: 1,  status: "flagged" },
];

export default function AdminPage() {
  const { signOutUser }  = useAuth();
  const { userName }     = useApp();

  const [adminTab,    setAdminTab]    = useState("overview");
  const [spots,       setSpots]       = useState([]);
  const [flagged,     setFlagged]     = useState(INITIAL_FLAGGED);
  const [loading,     setLoading]     = useState(true);
  const [editingSpot, setEditingSpot] = useState(null);

  useEffect(() => { loadSpots(); }, []);

  const loadSpots = async () => {
    setLoading(true);
    try {
      const data = await getAllSpots();
      setSpots(data);
    } catch (err) {
      console.error("Failed to load spots:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleSpotAdded   = (newSpot)     => setSpots((prev) => [newSpot, ...prev]);
  const handleSpotUpdated = (updatedSpot) => {
    setSpots((prev) => prev.map((s) => s.id === updatedSpot.id ? updatedSpot : s));
    setEditingSpot(null);
  };

  const handleDeleteSpot = async (id) => {
    if (!window.confirm("Are you sure you want to delete this spot?")) return;
    try {
      await deleteSpot(id);
      setSpots((prev) => prev.filter((s) => s.id !== id));
    } catch (err) {
      alert("Failed to delete spot. Please try again.");
    }
  };

  const handleDeleteFlagged = (id) => setFlagged((prev) => prev.filter((f) => f.id !== id));

  return (
    <div>
      {/* ── Admin Nav ──────────────────────────────────────── */}
      <div className="admin-nav">
        <div className="admin-nav-inner">
          <div className="admin-brand" style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
            <img
              src={bulacanSeal}
              alt="Bulacan"
              style={{ width: 32, height: 32, borderRadius: "50%", objectFit: "cover", border: "2px solid rgba(255,255,255,0.3)", flexShrink: 0 }}
            />
            BiyaheBulacan Admin
          </div>
          {["overview", "spots", "moderation", "users"].map((t) => (
            <button
              key={t}
              className={"admin-nav-link " + (adminTab === t ? "active" : "")}
              onClick={() => setAdminTab(t)}
            >
              {t.charAt(0).toUpperCase() + t.slice(1)}
              {t === "moderation" && flagged.length > 0 && <span className="notif-dot" />}
            </button>
          ))}
          <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: "0.75rem" }}>
            <span className="admin-user-label">Admin: {userName}</span>
            <button className="btn btn-sm admin-logout-btn" onClick={signOutUser}>Log Out</button>
          </div>
        </div>
      </div>

      <div className="admin-body container">

        {/* ── OVERVIEW ───────────────────────────────────────── */}
        {adminTab === "overview" && (
          <>
            <div className="admin-page-title">
              <h2>Admin Dashboard</h2>
              <p>System overview — BiyaheBulacan</p>
            </div>
            <div className="admin-stats">
              {[
                { icon: "🏛️", bg: "#e8f5ee", label: "Official Spots",   val: loading ? "..." : String(spots.length) },
                { icon: "👤", bg: "#fef3dc", label: "Registered Users", val: "1,284" },
                { icon: "⭐", bg: "#e8f0fe", label: "Total Reviews",    val: "3,917" },
                { icon: "🚩", bg: "#fce8f3", label: "Flagged Content",  val: String(flagged.length), danger: true },
              ].map((s) => (
                <div className="admin-stat" key={s.label}>
                  <div className="admin-stat-icon" style={{ background: s.bg }}>{s.icon}</div>
                  <div>
                    <div className="admin-stat-lbl">{s.label}</div>
                    <div className="admin-stat-val" style={s.danger ? { color: "#c0392b" } : {}}>{s.val}</div>
                  </div>
                </div>
              ))}
            </div>
            <div className="admin-grid">
              <div className="admin-table-card">
                <div className="admin-table-head">
                  <h3>Recent Tourist Spots</h3>
                  <button className="btn btn-pri btn-sm" onClick={() => setAdminTab("spots")}>+ Add Spot</button>
                </div>
                {loading ? (
                  <p style={{ padding: "1rem", color: "var(--muted)" }}>Loading spots...</p>
                ) : (
                  <table className="admin-table">
                    <thead>
                      <tr><th>Spot</th><th>Municipality</th><th>Category</th><th>Fee</th><th>Status</th><th></th></tr>
                    </thead>
                    <tbody>
                      {spots.slice(0, 5).map((s) => (
                        <tr key={s.id}>
                          <td>
                            <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
                              {s.imageUrl ? (
                                <img src={s.imageUrl} alt={s.name} style={{ width: 32, height: 32, borderRadius: 6, objectFit: "cover" }} />
                              ) : (
                                <div style={{ width: 32, height: 32, borderRadius: 6, background: s.bg, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "1rem" }}>
                                  {s.emoji}
                                </div>
                              )}
                              <strong>{s.name}</strong>
                            </div>
                          </td>
                          <td>{s.municipality}</td>
                          <td>{s.category}</td>
                          <td>{s.fee}</td>
                          <td><span className="status-badge status-active">✓ Active</span></td>
                          <td>
                            <span style={{ cursor: "pointer", marginRight: 8 }} onClick={() => { setEditingSpot(s); setAdminTab("spots"); }}>✏️</span>
                            <span style={{ cursor: "pointer" }} onClick={() => handleDeleteSpot(s.id)}>🗑️</span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
              <FlaggedPanel flagged={flagged} onDelete={handleDeleteFlagged} />
            </div>
          </>
        )}

        {/* ── SPOTS ──────────────────────────────────────────── */}
        {adminTab === "spots" && (
          <>
            <h2 className="admin-page-title-h">
              {editingSpot ? "Edit Spot" : "Manage Tourist Spots"}
            </h2>
            <SpotForm
              key={editingSpot?.id || "new"}
              municipalities={MUNICIPALITIES}
              categories={CATEGORIES}
              bgOptions={BG_OPTIONS}
              initialData={editingSpot}
              onSpotAdded={handleSpotAdded}
              onSpotUpdated={handleSpotUpdated}
              onCancelEdit={() => setEditingSpot(null)}
            />
            <div className="admin-table-card" style={{ marginTop: "1.5rem" }}>
              <div className="admin-table-head">
                <h3>All Official Spots ({loading ? "..." : spots.length})</h3>
                <button className="btn btn-sec btn-sm" onClick={loadSpots}>↻ Refresh</button>
              </div>
              {loading ? (
                <p style={{ padding: "1rem", color: "var(--muted)" }}>Loading...</p>
              ) : (
                <table className="admin-table">
                  <thead>
                    <tr><th>Spot</th><th>Municipality</th><th>Category</th><th>Fee</th><th>Rating</th><th>Actions</th></tr>
                  </thead>
                  <tbody>
                    {spots.map((s) => (
                      <tr key={s.id}>
                        <td>
                          <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
                            {s.imageUrl ? (
                              <img src={s.imageUrl} alt={s.name} style={{ width: 36, height: 36, borderRadius: 6, objectFit: "cover", flexShrink: 0 }} />
                            ) : (
                              <div style={{ width: 36, height: 36, borderRadius: 6, background: s.bg, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "1.2rem", flexShrink: 0 }}>
                                {s.emoji}
                              </div>
                            )}
                            <strong>{s.name}</strong>
                          </div>
                        </td>
                        <td>{s.municipality}</td>
                        <td>{s.category}</td>
                        <td>{s.fee}</td>
                        <td>{s.rating > 0 ? s.rating + " ★" : "—"}</td>
                        <td>
                          <button
                            className="btn btn-sec btn-sm"
                            style={{ marginRight: "0.4rem" }}
                            onClick={() => { setEditingSpot(s); window.scrollTo({ top: 0, behavior: "smooth" }); }}
                          >✏️ Edit</button>
                          <button
                            className="btn btn-sm"
                            style={{ background: "#fce8e8", color: "#c0392b", border: "none" }}
                            onClick={() => handleDeleteSpot(s.id)}
                          >🗑️ Delete</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </>
        )}

        {/* ── MODERATION ─────────────────────────────────────── */}
        {adminTab === "moderation" && (
          <>
            <h2 className="admin-page-title-h">Community Moderation</h2>
            <div className="admin-grid">
              <FlaggedPanel flagged={flagged} onDelete={handleDeleteFlagged} showCount />
              <div className="sidebar-card" style={{ alignSelf: "start" }}>
                <h4 className="sidebar-h4">Moderation Stats</h4>
                {[
                  ["Total posts reviewed", "2,841"],
                  ["Deleted this month",   "23"],
                  ["Auto-flagged",         String(flagged.length)],
                  ["Clean pass rate",      "99.2%"],
                ].map(([k, v]) => (
                  <div className="summary-row" key={k}>
                    <span style={{ fontSize: "0.875rem" }}>{k}</span>
                    <span style={{ fontSize: "0.875rem", fontWeight: 600 }}>{v}</span>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}

        {/* ── USERS ──────────────────────────────────────────── */}
        {adminTab === "users" && (
          <>
            <h2 className="admin-page-title-h">Registered Users</h2>
            <div className="admin-table-card">
              <div className="admin-table-head">
                <h3>All Users (1,284)</h3>
                <input type="text" placeholder="Search users..." style={{ padding: "5px 10px", border: "1px solid var(--border)", borderRadius: 6, fontFamily: "var(--font-body)", fontSize: "0.8rem", background: "var(--bg)" }} />
              </div>
              <table className="admin-table">
                <thead>
                  <tr><th>Name</th><th>Email</th><th>Joined</th><th>Reviews</th><th>Status</th><th>Actions</th></tr>
                </thead>
                <tbody>
                  {SAMPLE_USERS.map((u) => (
                    <tr key={u.name}>
                      <td><strong>{u.name}</strong></td>
                      <td>{u.email}</td>
                      <td>{u.joined}</td>
                      <td>{u.reviews}</td>
                      <td><span className={"status-badge status-" + u.status}>{u.status === "active" ? "✓ Active" : "⚠ Flagged"}</span></td>
                      <td><span className="action-icon">👁️</span><span className="action-icon">🚫</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
// ─── FlaggedPanel ─────────────────────────────────────────
function FlaggedPanel({ flagged, onDelete, showCount = false }) {
  return (
    <div className="admin-table-card">
      <div className="admin-table-head">
        <h3>Flagged Content {flagged.length > 0 && <span className="notif-dot" />}</h3>
        {showCount && <span className="status-badge status-flagged">{flagged.length} pending</span>}
      </div>
      {flagged.length === 0 ? (
        <p style={{ padding: "1.25rem", color: "var(--muted)", fontSize: "0.875rem" }}>
          All clear! No flagged content. ✓
        </p>
      ) : (
        flagged.map((f) => (
          <div className="mod-item" key={f.id}>
            <div className="mod-item-header">
              <span className="mod-user">{f.type} by: {f.user}</span>
              <span className="status-badge status-flagged">⚠ {f.label}</span>
            </div>
            <div className="mod-item-text">{f.text}</div>
            <div className="mod-actions">
              <button className="mod-del"  onClick={() => onDelete(f.id)}>Delete</button>
              <button className="mod-keep" onClick={() => onDelete(f.id)}>Keep</button>
            </div>
          </div>
        ))
      )}
    </div>
  );
}

// ─── SpotForm ─────────────────────────────────────────────
function SpotForm({ municipalities, categories, bgOptions, initialData, onSpotAdded, onSpotUpdated, onCancelEdit }) {
  const isEditing = !!initialData;

  const [form, setForm] = useState(initialData ? {
    name:         initialData.name         || "",
    municipality: initialData.municipality || "",
    category:     initialData.category     || "",
    fee:          initialData.fee          || "",
    pasalubong:   initialData.pasalubong   || "",
    hours:        initialData.hours        || "",
    desc:         initialData.desc         || "",
    badge:        initialData.badge        || "",
    emoji:        initialData.emoji        || "📍",
    bg:           initialData.bg           || "#e8f5ee",
    lat:          initialData.lat          || "",
    lng:          initialData.lng          || "",
    imageUrl:     initialData.imageUrl     || "",
    mapsLink:     "",
  } : EMPTY_FORM);

  const [submitting, setSubmitting] = useState(false);
  const [uploading,  setUploading]  = useState(false);
  const [success,    setSuccess]    = useState("");
  const [error,      setError]      = useState("");
  const [dragOver,   setDragOver]   = useState(false);
  const fileInputRef                = useRef(null);

  const handleChange = (e) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  // ─── Extract GPS from Google Maps URL ──────────────────
  const handleMapsLink = (e) => {
    const val = e.target.value;
    setForm((prev) => ({ ...prev, mapsLink: val }));

    // Extract @lat,lng from Google Maps URL
    const match = val.match(/@(-?\d+\.\d+),(-?\d+\.\d+)/);
    if (match) {
      setForm((prev) => ({
        ...prev,
        mapsLink: val,
        lat:      parseFloat(match[1]),
        lng:      parseFloat(match[2]),
      }));
    }
  };

  // ─── Upload image to Cloudinary ──────────────────────────
  const handleImageUpload = async (file) => {
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setError("Please upload an image file (JPG, PNG, WEBP).");
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      setError("Image must be under 10MB.");
      return;
    }

    setUploading(true);
    setError("");

    try {
      const CLOUD  = process.env.REACT_APP_CLOUDINARY_CLOUD;
      const PRESET = process.env.REACT_APP_CLOUDINARY_PRESET;

      console.log("Uploading... Cloud:", CLOUD, "Preset:", PRESET);

      const formData = new FormData();
      formData.append("file",          file);
      formData.append("upload_preset", PRESET);

      const res = await fetch(
        "https://api.cloudinary.com/v1_1/" + CLOUD + "/image/upload",
        { method: "POST", body: formData }
      );

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData?.error?.message || "Upload failed");
      }

      const data = await res.json();
      console.log("Upload success:", data.secure_url);
      setForm((prev) => ({ ...prev, imageUrl: data.secure_url }));

    } catch (err) {
      console.error("Upload error:", err);
      setError("Image upload failed: " + err.message);
    } finally {
      setUploading(false);
    }
  };

  // ─── Drag & drop ─────────────────────────────────────────
  const handleDrop      = (e) => { e.preventDefault(); setDragOver(false); handleImageUpload(e.dataTransfer.files[0]); };
  const handleDragOver  = (e) => { e.preventDefault(); setDragOver(true);  };
  const handleDragLeave = ()  => setDragOver(false);

  const handleClear = () => { setForm(EMPTY_FORM); setSuccess(""); setError(""); };

  // ─── Submit ───────────────────────────────────────────────
  const handleSubmit = async () => {
    setError("");
    setSuccess("");
    if (!form.name.trim())      { setError("Spot name is required.");    return; }
    if (!form.municipality)     { setError("Municipality is required."); return; }
    if (!form.category)         { setError("Category is required.");     return; }
    if (!form.fee.trim())       { setError("Entrance fee is required."); return; }
    if (!form.hours.trim())     { setError("Visit hours are required."); return; }
    if (!form.desc.trim())      { setError("Description is required.");  return; }

    setSubmitting(true);
    try {
      if (isEditing) {
        await updateSpot(initialData.id, form);
        setSuccess("✅ Spot updated successfully!");
        onSpotUpdated({ ...initialData, ...form });
      } else {
        const newSpot = await addSpot(form);
        setSuccess("✅ \"" + form.name + "\" published successfully!");
        onSpotAdded(newSpot);
        handleClear();
      }
    } catch (err) {
      console.error("SpotForm error:", err);
      setError("Failed to save spot. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="add-spot-form admin-table-card">
      <div className="admin-table-head">
        <h3>{isEditing ? "✏️ Editing: " + initialData.name : "Add New Tourist Spot"}</h3>
        {isEditing && (
          <button className="btn btn-sec btn-sm" onClick={onCancelEdit}>✕ Cancel Edit</button>
        )}
      </div>
      <div style={{ padding: "1.25rem" }}>

        {error   && <div className="auth-error" style={{ marginBottom: "1rem" }}>{error}</div>}
        {success && (
          <div style={{ background: "#e8f5ee", color: "#1a5c3c", padding: "0.75rem 1rem", borderRadius: 8, marginBottom: "1rem", fontSize: "0.875rem" }}>
            {success}
          </div>
        )}

        {/* ── Image Upload ──────────────────────────────────── */}
        <div style={{ marginBottom: "1rem" }}>
          <label style={{ fontSize: "0.85rem", fontWeight: 600, display: "block", marginBottom: "0.5rem" }}>
            Spot Photo
          </label>
          <div
            onDrop={handleDrop}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onClick={() => fileInputRef.current?.click()}
            style={{
              border:       "2px dashed " + (dragOver ? "#1a5c3c" : "var(--border)"),
              borderRadius: 10,
              padding:      "1.5rem",
              textAlign:    "center",
              cursor:       "pointer",
              background:   dragOver ? "#e8f5ee" : "transparent",
              transition:   "all 0.2s ease",
              marginBottom: "0.5rem",
            }}
          >
            {uploading ? (
              <div style={{ color: "var(--muted)", fontSize: "0.875rem" }}>
                ⏳ Uploading to Cloudinary...
              </div>
            ) : form.imageUrl ? (
              <div>
                <img
                  src={form.imageUrl}
                  alt="Preview"
                  style={{ width: "100%", maxHeight: 200, objectFit: "cover", borderRadius: 8, marginBottom: "0.5rem" }}
                />
                <div style={{ fontSize: "0.75rem", color: "var(--muted)" }}>
                  Click or drag to replace image
                </div>
              </div>
            ) : (
              <div>
                <div style={{ fontSize: "2rem", marginBottom: "0.4rem" }}>📸</div>
                <div style={{ fontSize: "0.875rem", fontWeight: 600, marginBottom: "0.2rem" }}>
                  Drag & drop a photo here
                </div>
                <div style={{ fontSize: "0.75rem", color: "var(--muted)" }}>
                  or click to browse — JPG, PNG, WEBP up to 10MB
                </div>
              </div>
            )}
          </div>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            style={{ display: "none" }}
            onChange={(e) => handleImageUpload(e.target.files[0])}
          />
          {form.imageUrl && !uploading && (
            <button
              className="btn btn-sec btn-sm"
              onClick={() => setForm((prev) => ({ ...prev, imageUrl: "" }))}
              style={{ fontSize: "0.75rem", marginTop: "0.25rem" }}
            >
              ✕ Remove photo
            </button>
          )}
        </div>

        {/* ── Form Fields ───────────────────────────────────── */}
        <div className="form-row">
          <div className="form-field">
            <label>Spot Name <span style={{ color: "red" }}>*</span></label>
            <input type="text" name="name" placeholder="e.g. Bocaue River Festival Grounds" value={form.name} onChange={handleChange} />
          </div>
          <div className="form-field">
            <label>Municipality <span style={{ color: "red" }}>*</span></label>
            <select name="municipality" value={form.municipality} onChange={handleChange}>
              <option value="">Select municipality</option>
              {municipalities.map((m) => <option key={m}>{m}</option>)}
            </select>
          </div>
        </div>

        <div className="form-row">
          <div className="form-field">
            <label>Category <span style={{ color: "red" }}>*</span></label>
            <select name="category" value={form.category} onChange={handleChange}>
              <option value="">Select category</option>
              {categories.map((c) => <option key={c}>{c}</option>)}
            </select>
          </div>
          <div className="form-field">
            <label>Entrance Fee <span style={{ color: "red" }}>*</span></label>
            <input type="text" name="fee" placeholder="₱50 or Free" value={form.fee} onChange={handleChange} />
          </div>
        </div>

        <div className="form-row">
          <div className="form-field">
            <label>Visit Hours <span style={{ color: "red" }}>*</span></label>
            <input type="text" name="hours" placeholder="e.g. 7:00 AM – 5:00 PM" value={form.hours} onChange={handleChange} />
          </div>
          <div className="form-field">
            <label>Badge <span style={{ color: "var(--muted)", fontSize: "0.8rem" }}>(optional)</span></label>
            <input type="text" name="badge" placeholder="e.g. National Shrine" value={form.badge} onChange={handleChange} />
          </div>
        </div>

        <div className="form-row">
          <div className="form-field">
            <label>Pasalubong / What to Buy</label>
            <input type="text" name="pasalubong" placeholder="e.g. Pastillas, Woven crafts" value={form.pasalubong} onChange={handleChange} />
          </div>
          <div className="form-field">
            <label>Emoji <span style={{ color: "var(--muted)", fontSize: "0.8rem" }}>(fallback if no photo)</span></label>
            <input type="text" name="emoji" placeholder="e.g. ⛪ 🏛️ ⛰️" value={form.emoji} onChange={handleChange} />
          </div>
        </div>

        <div className="form-row">
          <div className="form-field">
            <label>Card Color <span style={{ color: "var(--muted)", fontSize: "0.8rem" }}>(fallback if no photo)</span></label>
            <select name="bg" value={form.bg} onChange={handleChange}>
              {bgOptions.map((b) => <option key={b.value} value={b.value}>{b.label}</option>)}
            </select>
          </div>

          {/* ── Google Maps Link → auto GPS ──────────────── */}
          <div className="form-field">
            <label>
              Google Maps Link{" "}
              <span style={{ color: "var(--muted)", fontSize: "0.75rem" }}>(auto-fills GPS)</span>
            </label>
            <input
              type="text"
              name="mapsLink"
              placeholder="https://www.google.com/maps/place/..."
              value={form.mapsLink || ""}
              onChange={handleMapsLink}
            />
            {form.lat && form.lng && (
              <div style={{ marginTop: "0.4rem", fontSize: "0.75rem", color: "#2ecc71", fontWeight: 600, display: "flex", alignItems: "center", gap: "0.3rem" }}>
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3">
                  <polyline points="20 6 9 17 4 12"/>
                </svg>
                {"GPS: " + form.lat + ", " + form.lng}
              </div>
            )}
          </div>
        </div>

        <div className="form-field" style={{ marginBottom: "0.75rem" }}>
          <label>Description <span style={{ color: "red" }}>*</span></label>
          <textarea
            name="desc"
            placeholder="Describe the tourist spot — history, what to see, tips for visitors..."
            value={form.desc}
            onChange={handleChange}
            style={{ width: "100%", padding: "8px 10px", border: "1.5px solid var(--border)", borderRadius: 7, fontFamily: "var(--font-body)", fontSize: "0.85rem", minHeight: 100, background: "var(--bg)", outline: "none", resize: "vertical" }}
          />
        </div>

        {/* ── Preview Card ──────────────────────────────────── */}
        {form.name && (
          <div style={{ marginBottom: "1rem", padding: "0.75rem", background: "var(--bg-secondary)", borderRadius: 8, border: "1px solid var(--border)" }}>
            <div style={{ fontSize: "0.7rem", color: "var(--muted)", marginBottom: "0.4rem", fontWeight: 600, letterSpacing: "0.05em" }}>
              PREVIEW
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: "0.75rem" }}>
              {form.imageUrl ? (
                <img src={form.imageUrl} alt="preview" style={{ width: 52, height: 52, borderRadius: 8, objectFit: "cover" }} />
              ) : (
                <div style={{ width: 52, height: 52, borderRadius: 8, background: form.bg, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "1.6rem" }}>
                  {form.emoji}
                </div>
              )}
              <div>
                <div style={{ fontWeight: 700, fontSize: "0.9rem" }}>{form.name}</div>
                <div style={{ fontSize: "0.78rem", color: "var(--muted)" }}>
                  {"📍 " + (form.municipality || "Municipality") + " · " + (form.category || "Category") + " · " + (form.fee || "Fee")}
                </div>
                {form.lat && form.lng && (
                  <div style={{ fontSize: "0.72rem", color: "var(--muted)", marginTop: 2 }}>
                    {"🗺️ " + form.lat + ", " + form.lng}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* ── Action Buttons ────────────────────────────────── */}
        <div style={{ display: "flex", gap: "0.75rem", justifyContent: "flex-end" }}>
          {isEditing ? (
            <>
              <button className="btn btn-sec btn-sm" onClick={onCancelEdit} disabled={submitting}>Cancel</button>
              <button className="btn btn-pri btn-sm" onClick={handleSubmit} disabled={submitting || uploading}>
                {submitting ? "Saving..." : "💾 Save Changes"}
              </button>
            </>
          ) : (
            <>
              <button className="btn btn-sec btn-sm" onClick={handleClear} disabled={submitting}>Clear</button>
              <button className="btn btn-pri btn-sm" onClick={handleSubmit} disabled={submitting || uploading}>
                {submitting ? "Publishing..." : "🚀 Publish Spot"}
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}