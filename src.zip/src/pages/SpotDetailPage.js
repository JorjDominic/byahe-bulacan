import { useState, useEffect } from "react";
import { useApp } from "../context/AppContext";
import { getTodayPH, getPHTime, timeToMinutes, minutesToTime, getTripStatus } from "../hooks/useItinerary";
import ROUTES from "../constants/routes";
import Stars from "../components/Stars";
import {
  getSpotById,
  getNearbySpots,
  getReviewsForSpot,
  addReview,
} from "../services/spotService";

const ALL_TIMES = [
  "7:00 AM","8:00 AM","9:00 AM","10:00 AM","11:00 AM",
  "12:00 PM","1:00 PM","2:00 PM","3:00 PM","4:00 PM",
  "5:00 PM","6:00 PM",
];

export default function SpotDetailPage({ spotId }) {
  // Added isPremium and itineraryDates to context extraction
  const { navigate, userId, userName, addToItinerary, itineraries, itineraryDates, isPremium } = useApp();
  
  const todayPH            = getTodayPH();
  const [tripDate,         setTripDate]         = useState(todayPH);
  const [arrivalTime,      setArrivalTime]       = useState("9:00 AM");
  const [timeError,        setTimeError]         = useState("");
  const [suggestedTime,    setSuggestedTime]     = useState("");
  const [availableTimes,   setAvailableTimes]    = useState(ALL_TIMES);
  const [spot,             setSpot]              = useState(null);
  const [nearbySpots,      setNearbySpots]       = useState([]);
  const [reviews,          setReviews]           = useState([]);
  const [userStars,        setUserStars]         = useState(0);
  const [reviewText,       setReviewText]        = useState("");
  const [loading,          setLoading]           = useState(true);
  const [submitting,       setSubmitting]        = useState(false);
  const [weather,          setWeather]           = useState(null);
  const [weatherLoading,   setWeatherLoading]    = useState(false);

  useEffect(() => {
    setLoading(true);
    Promise.all([
      getSpotById(spotId),
      getNearbySpots(spotId),
      getReviewsForSpot(spotId),
    ]).then(([spotData, nearby, reviewData]) => {
      setSpot(spotData);
      setNearbySpots(nearby);
      setReviews(reviewData ?? []);
      setLoading(false);
      if (spotData?.lat && spotData?.lng) fetchWeather(spotData.lat, spotData.lng);
    });
  }, [spotId]);

  useEffect(() => {
    recalcTimes(tripDate);
  }, [tripDate, itineraries]);

  const recalcTimes = (date) => {
    const ph         = getPHTime();
    const curMins    = ph.getHours() * 60 + ph.getMinutes();
    const isToday    = date === getTodayPH();
    const itin       = itineraries[date] || { spots: [], minGap: 3 };
    const gapMins    = (itin.minGap ?? 3) * 60;
    const takenMins  = (itin.spots ?? []).map((s) => timeToMinutes(s.time));

    const avail = ALL_TIMES.filter((t) => {
      const mins = timeToMinutes(t);
      if (isToday && mins <= curMins) return false;
      for (const taken of takenMins) {
        if (Math.abs(mins - taken) < gapMins) return false;
      }
      return true;
    });

    setAvailableTimes(avail);

    if (avail.length > 0) {
      setArrivalTime(avail[0]);
      setTimeError("");
    } else {
      setTimeError("No available times for this date. All slots are taken or passed.");
    }

    if (takenMins.length > 0) {
      const lastMins  = Math.max(...takenMins);
      const suggested = lastMins + (itin.minGap ?? 3) * 60;
      const sugStr    = minutesToTime(suggested);
      if (sugStr && avail.includes(sugStr)) {
        setSuggestedTime(sugStr);
        setArrivalTime(sugStr);
      } else if (avail.length > 0) {
        setSuggestedTime(avail[0]);
        setArrivalTime(avail[0]);
      }
    }
  };

  const handleTimeChange = (time) => {
    setArrivalTime(time);
    setTimeError("");
    const itin    = itineraries[tripDate] || { spots: [], minGap: 3 };
    const gapMins = (itin.minGap ?? 3) * 60;
    const newMins = timeToMinutes(time);

    for (const s of (itin.spots ?? [])) {
      const diff = Math.abs(newMins - timeToMinutes(s.time));
      if (diff < gapMins) {
        setTimeError(
          "⚠️ Too close to " + s.name + " at " + s.time +
          ". Minimum gap is " + (itin.minGap ?? 3) + " hrs. " +
          "Try " + (suggestedTime || availableTimes[0] || "a later time") + " instead."
        );
        return;
      }
    }
  };

  const handleAddToItinerary = () => {
    if (!spot || !userId || timeError || availableTimes.length === 0) return;
    addToItinerary(tripDate, { ...spot, time: arrivalTime, tripDate });
    navigate(ROUTES.ITINERARY);
  };

  // --- FREEMIUM LOGIC ---
  const itin = itineraries[tripDate] || { spots: [] };
  const alreadyAdded = (itin.spots ?? []).some((s) => s.id === spot?.id);
  const tripStatus = getTripStatus(tripDate);
  
  // 1. Max Spots Logic
  const currentStopsCount = (itin.spots ?? []).length;
  const isFreeMaxStopsReached = !isPremium && currentStopsCount >= 3;
  
  // 2. Max Itineraries Logic (Limit to 1 date)
  const isFreeMaxTripsReached = !isPremium && itineraryDates.length >= 1 && !itineraryDates.includes(tripDate);
  
  // Is the button globally blocked by a paywall?
  const isBlockedByPaywall = isFreeMaxStopsReached || isFreeMaxTripsReached;


  const fetchWeather = async (lat, lng) => {
    const key = process.env.REACT_APP_WEATHER_KEY;
    if (!key) return;
    setWeatherLoading(true);
    try {
      const res  = await fetch(
        "https://api.openweathermap.org/data/2.5/weather?lat=" + lat +
        "&lon=" + lng + "&appid=" + key + "&units=metric"
      );
      const data = await res.json();
      if (data.main) {
        setWeather({
          temp:     Math.round(data.main.temp),
          feels:    Math.round(data.main.feels_like),
          desc:     data.weather[0].description,
          humidity: data.main.humidity,
          wind:     data.wind.speed,
          icon:     data.weather[0].main,
        });
      }
    } catch (err) {
      console.error("Weather error:", err);
    } finally {
      setWeatherLoading(false);
    }
  };

  const getWeatherEmoji = (icon) => {
    const map = { Clear:"☀️", Clouds:"☁️", Rain:"🌧️", Drizzle:"🌦️", Thunderstorm:"⛈️", Snow:"❄️", Mist:"🌫️", Fog:"🌫️", Haze:"🌁" };
    return map[icon] || "⛅";
  };

  const formatTime = (item) => {
    if (item.createdAt?.toDate) {
      const diff  = Date.now() - item.createdAt.toDate().getTime();
      const mins  = Math.floor(diff / 60000);
      const hours = Math.floor(diff / 3600000);
      if (mins  <  1) return "Just now";
      if (mins  < 60) return mins  + "m ago";
      if (hours < 24) return hours + "h ago";
      return Math.floor(diff / 86400000) + "d ago";
    }
    return item.time || "Just now";
  };

  const handleSubmitReview = async () => {
    if (userStars === 0 || !reviewText.trim() || submitting) return;
    setSubmitting(true);
    try {
      const newReview = await addReview(spot.id, userId, userName || "Anonymous", userStars, reviewText.trim());
      setReviews((prev) => [newReview, ...prev]);
      setReviewText("");
      setUserStars(0);
    } catch (err) {
      alert("Failed to submit review.");
    } finally {
      setSubmitting(false);
    }
  };

  const handleOpenMaps = () => {
    const q = spot.lat && spot.lng
      ? spot.lat + "," + spot.lng
      : encodeURIComponent(spot.name + " " + spot.municipality + " Bulacan");
    window.open("https://www.google.com/maps/search/?api=1&query=" + q, "_blank");
  };

  if (loading) return (
    <div className="container" style={{ padding: "3rem", textAlign: "center", color: "var(--muted)" }}>
      <div style={{ fontSize: "2rem", marginBottom: "0.5rem" }}>🗺️</div>
      Loading spot details...
    </div>
  );

  if (!spot) return (
    <div className="container" style={{ padding: "2rem" }}>Spot not found.</div>
  );

  return (
    <div>
      <div className="detail-hero">
        <div className="container">
          <span className="back-link" onClick={() => navigate(ROUTES.BROWSE)}>← Back to Explore</span>
          
          <div className="detail-inner">
            {/* ── Left ─────────────────────────────────────────────── */}
            <div>
              {spot.imageUrl ? (
                <div className="detail-big-img" style={{ padding: 0, overflow: "hidden" }}>
                  <img src={spot.imageUrl} alt={spot.name} style={{ width: "100%", height: "100%", objectFit: "cover", borderRadius: 12 }} />
                </div>
              ) : (
                <div className="detail-big-img" style={{ background: spot.bg }}>{spot.emoji}</div>
              )}
              <h2 className="detail-name">{spot.name}</h2>
              <div className="info-pills">
                <span className="pill pill-green">{spot.category}</span>
                {spot.badge && <span className="pill pill-amber">{spot.badge}</span>}
              </div>

              <div className="stars-row">
                <Stars rating={spot.rating || 0} size="lg" />
                <span className="review-count">
                  {spot.rating > 0 ? spot.rating : "No ratings yet"}
                  {" (" + (spot.reviews ?? 0) + " reviews)"}
                </span>
              </div>

              <div className="info-grid">
                <div className="info-item"><div className="info-lbl">Municipality</div><div className="info-val">{spot.municipality + ", Bulacan"}</div></div>
                <div className="info-item"><div className="info-lbl">Entrance Fee</div><div className="info-val">{spot.fee === "Free" ? "Free entrance" : spot.fee + " per person"}</div></div>
                <div className="info-item"><div className="info-lbl">Pasalubong</div><div className="info-val">{spot.pasalubong || "—"}</div></div>
                <div className="info-item"><div className="info-lbl">Best Visit Hours</div><div className="info-val">{spot.hours || "—"}</div></div>
              </div>

              <div className="detail-desc">{spot.desc}</div>

              {/* Weather */}
              {(weather || weatherLoading) && (
                <div style={{ marginTop: "1rem", padding: "0.875rem 1rem", background: "var(--bg-secondary)", borderRadius: 10, border: "1px solid var(--border)" }}>
                  <div style={{ fontSize: "0.75rem", fontWeight: 600, color: "var(--muted)", marginBottom: "0.5rem" }}>
                    {"CURRENT WEATHER IN " + spot.municipality.toUpperCase() + ", BULACAN"}
                  </div>
                  {weatherLoading ? (
                    <p style={{ color: "var(--muted)", fontSize: "0.875rem" }}>Fetching weather...</p>
                  ) : weather && (
                    <div style={{ display: "flex", alignItems: "center", gap: "1rem", flexWrap: "wrap" }}>
                      <div style={{ fontSize: "2.5rem" }}>{getWeatherEmoji(weather.icon)}</div>
                      <div>
                        <div style={{ fontSize: "1.5rem", fontWeight: 700 }}>{weather.temp + "°C"}</div>
                        <div style={{ fontSize: "0.8rem", color: "var(--muted)", textTransform: "capitalize" }}>{weather.desc + " • Feels like " + weather.feels + "°C"}</div>
                      </div>
                      <div style={{ marginLeft: "auto", textAlign: "right" }}>
                        <div style={{ fontSize: "0.8rem", color: "var(--muted)" }}>{"💧 " + weather.humidity + "%"}</div>
                        <div style={{ fontSize: "0.8rem", color: "var(--muted)" }}>{"💨 " + weather.wind + " m/s"}</div>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* ── Right ────────────────────────────────────────────── */}
            <div>
              <div className="add-itin-card">
                <h4>Plan Your Visit</h4>
                <p style={{ fontSize: "0.875rem", color: "var(--muted)", marginBottom: "1rem" }}>
                  Choose a date and arrival time for this spot.
                </p>

                {userId ? (
                  <>
                    <label className="time-label">Trip date</label>
                    <input
                      type="date"
                      value={tripDate}
                      min={todayPH}
                      onChange={(e) => {
                        setTripDate(e.target.value);
                        setTimeError("");
                      }}
                      style={{
                        width: "100%", padding: "8px 10px",
                        border: "1.5px solid rgba(255,255,255,0.3)",
                        borderRadius: 8, fontFamily: "var(--font-body)",
                        fontSize: "0.875rem", background: "rgba(255,255,255,0.15)",
                        color: "#fff", marginBottom: "0.75rem", boxSizing: "border-box",
                      }}
                    />

                    {/* FREEMIUM WARNING: Max Trips Reached */}
                    {isFreeMaxTripsReached && (
                      <div style={{ padding: "0.75rem", background: "rgba(244, 161, 36, 0.2)", border: "1px solid #f4a124", borderRadius: 8, fontSize: "0.8rem", color: "#ffd580", marginBottom: "1rem", lineHeight: 1.5 }}>
                        <strong>🔒 Free Tier Limit Reached</strong><br/>
                        You already have an active itinerary on {itineraryDates[0]}. Upgrade to Premium to plan multi-day trips!
                      </div>
                    )}

                    {/* FREEMIUM WARNING: Max Stops Reached on this date */}
                    {isFreeMaxStopsReached && !isFreeMaxTripsReached && (
                       <div style={{ padding: "0.75rem", background: "rgba(244, 161, 36, 0.2)", border: "1px solid #f4a124", borderRadius: 8, fontSize: "0.8rem", color: "#ffd580", marginBottom: "1rem", lineHeight: 1.5 }}>
                       <strong>🔒 Free Tier Limit Reached</strong><br/>
                       You have reached the maximum of 3 stops for this day. Upgrade to Premium for unlimited stops!
                     </div>
                    )}

                    {(itin.spots ?? []).length > 0 && (
                      <div style={{ marginBottom: "0.75rem", padding: "0.6rem 0.75rem", background: "rgba(255,255,255,0.1)", borderRadius: 8 }}>
                        <div style={{ fontSize: "0.72rem", fontWeight: 600, color: "rgba(255,255,255,0.7)", marginBottom: "0.3rem" }}>
                          ALREADY PLANNED ON THIS DATE:
                        </div>
                        {(itin.spots ?? []).map((s) => (
                          <div key={s.id} style={{ fontSize: "0.78rem", color: "rgba(255,255,255,0.85)", marginBottom: "0.15rem" }}>
                            • {s.time} - {s.name}
                          </div>
                        ))}
                      </div>
                    )}

                    {suggestedTime && availableTimes.includes(suggestedTime) && !isBlockedByPaywall && (
                      <div style={{ marginBottom: "0.5rem", fontSize: "0.78rem", color: "rgba(255,255,255,0.8)" }}>
                        ✨ Suggested: <strong>{suggestedTime}</strong>
                        <button
                          onClick={() => { setArrivalTime(suggestedTime); setTimeError(""); }}
                          style={{ marginLeft: "0.4rem", background: "rgba(255,255,255,0.2)", border: "none", borderRadius: 4, padding: "1px 8px", color: "#fff", cursor: "pointer", fontSize: "0.72rem" }}
                        >
                          Use this
                        </button>
                      </div>
                    )}

                    {!isBlockedByPaywall && (
                      <>
                        <label className="time-label">Select arrival time</label>
                        {availableTimes.length === 0 ? (
                          <div style={{ padding: "0.6rem 0.75rem", background: "rgba(255,0,0,0.15)", borderRadius: 8, fontSize: "0.8rem", color: "#ffb3b3", marginBottom: "0.75rem" }}>
                            No available times for this date. Try another date.
                          </div>
                        ) : (
                          <select
                            className="time-select"
                            value={arrivalTime}
                            onChange={(e) => handleTimeChange(e.target.value)}
                          >
                            {availableTimes.map((t) => <option key={t}>{t}</option>)}
                          </select>
                        )}
                      </>
                    )}

                    {timeError && !isBlockedByPaywall && (
                      <div style={{ padding: "0.6rem 0.75rem", background: "rgba(255,0,0,0.15)", borderRadius: 8, fontSize: "0.78rem", color: "#ffb3b3", marginBottom: "0.75rem", lineHeight: 1.5 }}>
                        {timeError}
                      </div>
                    )}

                    {/* ✨ THIS IS THE UPDATED BUTTON LOGIC ✨ */}
                    <button
                      className="add-btn"
                      onClick={() => isBlockedByPaywall ? navigate(ROUTES.PREMIUM) : handleAddToItinerary()}
                      disabled={alreadyAdded || (!!timeError && !isBlockedByPaywall) || (availableTimes.length === 0 && !isBlockedByPaywall)}
                    >
                      {alreadyAdded 
                        ? "✓ Already in " + tripDate + " itinerary" 
                        : isBlockedByPaywall 
                        ? "⭐ Upgrade to Unlock"
                        : "+ Add to " + tripDate + " Itinerary"
                      }
                    </button>
                    {/* ✨ END UPDATED BUTTON ✨ */}

                    {spot.feeNum > 0 && !isBlockedByPaywall && (
                      <div className="fee-note">
                        {"Entrance: ₱" + spot.feeNum + " will be added to your trip total"}
                      </div>
                    )}

                    {tripStatus === "done" && (
                      <div style={{ marginTop: "0.5rem", fontSize: "0.75rem", color: "rgba(255,255,255,0.6)", textAlign: "center" }}>
                        This date has already passed.
                      </div>
                    )}
                  </>
                ) : (
                  <div style={{ textAlign: "center", padding: "1.5rem 1rem", background: "rgba(255,255,255,0.08)", borderRadius: 10, border: "1.5px dashed rgba(255,255,255,0.3)" }}>
                    <div style={{ fontSize: "2rem", marginBottom: "0.5rem" }}>🔒</div>
                    <div style={{ fontWeight: 700, fontSize: "0.95rem", marginBottom: "0.35rem", color: "#fff" }}>Login required</div>
                    <div style={{ fontSize: "0.82rem", color: "rgba(255,255,255,0.75)", marginBottom: "1.25rem", lineHeight: 1.6 }}>
                      Log in or create a free account to add spots to your itinerary.
                    </div>
                    <div style={{ display: "flex", gap: "0.6rem" }}>
                      <button onClick={() => navigate(ROUTES.LOGIN)} style={{ flex: 1, padding: "0.6rem 1rem", borderRadius: 8, border: "none", background: "#ffffff", color: "#1a5c3c", fontWeight: 700, fontSize: "0.85rem", cursor: "pointer" }}>Log In</button>
                    </div>
                  </div>
                )}
              </div>

              {/* Location */}
              {spot.lat && spot.lng && (
                <div className="sidebar-card" style={{ marginTop: "1rem" }}>
                  <h4 className="sidebar-h4">Location</h4>
                  <div style={{ fontSize: "0.8rem", color: "var(--muted)", marginBottom: "0.4rem" }}>{"📍 " + spot.municipality + ", Bulacan"}</div>
                  <div style={{ fontSize: "0.75rem", color: "var(--muted)", marginBottom: "0.75rem" }}>{"GPS: " + spot.lat + ", " + spot.lng}</div>
                  <button className="btn btn-sec btn-sm" style={{ width: "100%" }} onClick={handleOpenMaps}>↗ Open in Google Maps</button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* ── Reviews + Nearby ─────────────────────────────────────── */}
      <div className="detail-body container">
        <div className="reviews-col">
          <h3 className="section-h3">Traveler Reviews</h3>
          {userId ? (
            <div className="write-review">
              <div className="write-review-title">Share your experience</div>
              <div className="star-picker">
                {[1,2,3,4,5].map((n) => (
                  <span key={n} className={n <= userStars ? "star-filled" : "star-empty"} onClick={() => setUserStars(n)}>★</span>
                ))}
              </div>
              <textarea
                className="review-textarea"
                placeholder="What did you love about this place? Share tips for future visitors..."
                value={reviewText}
                onChange={(e) => setReviewText(e.target.value)}
                disabled={submitting}
              />
              <div style={{ display: "flex", justifyContent: "flex-end", marginTop: "0.5rem" }}>
                <button className="btn btn-pri btn-sm" onClick={handleSubmitReview} disabled={submitting || userStars === 0 || !reviewText.trim()}>
                  {submitting ? "Posting..." : "Post Review"}
                </button>
              </div>
            </div>
          ) : (
            <div style={{ padding: "1rem", background: "var(--bg-secondary)", borderRadius: 8, marginBottom: "1rem", fontSize: "0.875rem", color: "var(--muted)", textAlign: "center" }}>
              <span className="link-text" onClick={() => navigate(ROUTES.LOGIN)}>Log in</span>{" to write a review."}
            </div>
          )}

          {reviews.length === 0 ? (
            <p style={{ color: "var(--muted)", fontSize: "0.875rem" }}>No reviews yet. Be the first to review!</p>
          ) : (
            reviews.map((r) => (
              <div className="review-card" key={r.id}>
                <div className="review-meta">
                  <span className="review-user">{r.user}</span>
                  <span className="stars">{Array(r.stars).fill("★").join("") + Array(5 - r.stars).fill("☆").join("")}</span>
                  <span className="review-time">{formatTime(r)}</span>
                </div>
                <div className="review-text">{r.text}</div>
              </div>
            ))
          )}
        </div>

        <div className="nearby-col">
          <div className="sidebar-card">
            <h4 className="sidebar-h4">Nearby Spots</h4>
            {nearbySpots.length === 0 ? (
              <p style={{ fontSize: "0.875rem", color: "var(--muted)" }}>No nearby spots found.</p>
            ) : (
              nearbySpots.map((s) => (
                <div className="nearby-item" key={s.id} onClick={() => navigate(ROUTES.SPOT(s.id))}>
                  {s.imageUrl ? (
                    <img src={s.imageUrl} alt={s.name} style={{ width: 36, height: 36, borderRadius: 8, objectFit: "cover", flexShrink: 0 }} />
                  ) : (
                    <span className="nearby-emoji">{s.emoji}</span>
                  )}
                  <div>
                    <div className="nearby-name">{s.name}</div>
                    <div className="nearby-sub">{s.municipality + " • " + s.fee}</div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}