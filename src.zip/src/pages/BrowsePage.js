import { useState, useEffect } from "react";
import { useApp } from "../context/AppContext";
import ROUTES from "../constants/routes";
import SpotCard from "../components/SpotCard";
import FlashLoader from "../components/FlashLoader"; // Added
import { filterSpots, getMunicipalities, getCategories } from "../services/spotService";

export default function BrowsePage() {
  const { navigate } = useApp();
  const [search, setSearch] = useState("");
  const [municipality, setMunicipality] = useState("All");
  const [category, setCategory] = useState("All");
  const [filtered, setFiltered] = useState([]);
  const [allSpots, setAllSpots] = useState([]);
  const [municipalities, setMunicipalities] = useState(["All"]);
  const [categories, setCategories] = useState(["All"]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([getMunicipalities(), getCategories()]).then(([munis, cats]) => {
      setMunicipalities(munis);
      setCategories(cats);
    });
  }, []);

  useEffect(() => {
    setLoading(true);
    filterSpots({ search: "", municipality: "All", category: "All" })
      .then((data) => {
        setAllSpots(data);
        setFiltered(data);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (allSpots.length === 0) return;
    const result = allSpots.filter((s) => {
      const matchSearch =
        search === "" ||
        s.name.toLowerCase().includes(search.toLowerCase()) ||
        s.municipality.toLowerCase().includes(search.toLowerCase()) ||
        s.category.toLowerCase().includes(search.toLowerCase());
      const matchMuni = municipality === "All" || s.municipality === municipality;
      const matchCat = category === "All" || s.category === category;
      return matchSearch && matchMuni && matchCat;
    });
    setFiltered(result);
  }, [search, municipality, category, allSpots]);

  const handleReset = () => {
    setSearch("");
    setMunicipality("All");
    setCategory("All");
  };

  const hasFilters = search !== "" || municipality !== "All" || category !== "All";

  return (
    <div>
      {/* Integrates Fullscreen Preloader */}
      <FlashLoader isLoading={loading} />

      <div className="browse-header">
        <div className="container">
          <h2 style={{ fontFamily: "var(--font-head)", fontSize: "1.5rem", marginBottom: "0.75rem" }}>
            Explore Bulacan Destinations
          </h2>
          <div className="filter-row">
            <input
              type="text"
              placeholder="Search spots, municipalities..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="search-input"
            />
            <select value={municipality} onChange={(e) => setMunicipality(e.target.value)}>
              {municipalities.map((m) => (
                <option key={m} value={m}>
                  {m === "All" ? "All Municipalities" : m}
                </option>
              ))}
            </select>
            <select value={category} onChange={(e) => setCategory(e.target.value)}>
              {categories.map((c) => (
                <option key={c} value={c}>
                  {c === "All" ? "All Categories" : c}
                </option>
              ))}
            </select>
            {hasFilters && (
              <button className="btn btn-sec btn-sm" onClick={handleReset} style={{ whiteSpace: "nowrap" }}>
                Clear
              </button>
            )}
          </div>
          {!loading && (
            <div style={{ fontSize: "0.8rem", color: "var(--muted)", marginTop: "0.5rem" }}>
              {hasFilters ? `${filtered.length} of ${allSpots.length} spots` : `${allSpots.length} spots total`}
            </div>
          )}
        </div>
      </div>

      <div className="spots-grid container" style={{ paddingTop: "1.5rem", paddingBottom: "2rem" }}>
        {filtered.length === 0 && !loading ? (
          <div style={{ gridColumn: "1/-1", textAlign: "center", padding: "3rem 1rem" }}>
            <div style={{ fontSize: "2rem", marginBottom: "0.5rem" }}>🏝️</div>
            <p style={{ color: "var(--muted)", marginBottom: "1rem" }}>No spots found for your search.</p>
            <button className="btn btn-sec btn-sm" onClick={handleReset}>
              Clear filters
            </button>
          </div>
        ) : (
          filtered.map((s) => <SpotCard key={s.id} spot={s} onClick={() => navigate(ROUTES.SPOT(s.id))} />)
        )}
      </div>
    </div>
  );
}