import { useState } from "react";
import { useApp } from "../context/AppContext";
import { useAuth } from "../hooks/useAuth";
import ROUTES from "../constants/routes";
import bulacanSeal from "../assets/images/bulacan-seal.jpg";
import ProfileModal from "./ProfileModal";

export default function Nav() {
  const { page, isLoggedIn, isAdmin, navigate, userName, avatarUrl } = useApp();
  const { signOutUser } = useAuth();
  const [showProfile, setShowProfile] = useState(false);

  if (isAdmin) return null;

  const initials = userName
    ? userName.split(" ").map((n) => n[0]).join("").slice(0, 2).toUpperCase()
    : "?";

  return (
    <>
      <nav className="nav">
        <div className="nav-inner">
          {/* ── Logo ─────────────────────────────────────── */}
          <div
            className="logo"
            onClick={() => navigate(isLoggedIn ? ROUTES.DASHBOARD : ROUTES.LANDING)}
            style={{ display: "flex", alignItems: "center", gap: "0.6rem", cursor: "pointer" }}
          >
            <img
              src={bulacanSeal}
              alt="Bulacan Seal"
              style={{
                width:          42,
                height:         42,
                borderRadius:   "50%",
                objectFit:      "cover",
                objectPosition: "center",
                border:         "2.5px solid #1a5c3c",
                boxShadow:      "0 1px 4px rgba(0,0,0,0.15)",
                background:     "#fff",
                flexShrink:     0,
              }}
            />
            <span style={{ fontWeight: 700, fontSize: "1.05rem", letterSpacing: "-0.01em" }}>
              BiyaheBulacan
            </span>
          </div>

          {/* ── Nav Links ────────────────────────────────── */}
          <div className="nav-links">
            {!isLoggedIn ? (
              <>
                <button className={`nav-btn ${page === ROUTES.LANDING ? "active" : ""}`} onClick={() => navigate(ROUTES.LANDING)}>Home</button>
                <button className={`nav-btn ${page === ROUTES.BROWSE  ? "active" : ""}`} onClick={() => navigate(ROUTES.BROWSE)}>Explore</button>
                <button className={`nav-btn ${page === ROUTES.FEED    ? "active" : ""}`} onClick={() => navigate(ROUTES.FEED)}>Community</button>
                <button className="btn btn-sec btn-sm" onClick={() => navigate(ROUTES.LOGIN)}>Log In</button>
                <button className="btn btn-pri btn-sm" onClick={() => navigate(ROUTES.LOGIN)}>Sign Up</button>
              </>
            ) : (
              <>
                <button className={`nav-btn ${page === ROUTES.DASHBOARD ? "active" : ""}`} onClick={() => navigate(ROUTES.DASHBOARD)}>Home</button>
                <button className={`nav-btn ${page === ROUTES.BROWSE    ? "active" : ""}`} onClick={() => navigate(ROUTES.BROWSE)}>Explore</button>
                <button className={`nav-btn ${page === ROUTES.ITINERARY ? "active" : ""}`} onClick={() => navigate(ROUTES.ITINERARY)}>My Itinerary</button>
                <button className={`nav-btn ${page === ROUTES.FEED      ? "active" : ""}`} onClick={() => navigate(ROUTES.FEED)}>Community</button>

                {/* ── Clickable Avatar ──────────────────── */}
                <div
                  onClick={() => setShowProfile(true)}
                  style={{ cursor: "pointer", position: "relative", flexShrink: 0 }}
                  title="View Profile"
                >
                  <div style={{
                    width:          36,
                    height:         36,
                    borderRadius:   "50%",
                    overflow:       "hidden",
                    border:         "2.5px solid var(--pri)",
                    display:        "flex",
                    alignItems:     "center",
                    justifyContent: "center",
                    background:     "#1a5c3c",
                    color:          "#fff",
                    fontWeight:     700,
                    fontSize:       "0.85rem",
                  }}>
                    {avatarUrl ? (
                      <img
                        src={avatarUrl}
                        alt="Profile"
                        style={{ width: "100%", height: "100%", objectFit: "cover" }}
                      />
                    ) : (
                      initials
                    )}
                  </div>
                  {/* Edit indicator */}
                  <div style={{
                    position:       "absolute",
                    bottom:         -2,
                    right:          -2,
                    width:          14,
                    height:         14,
                    borderRadius:   "50%",
                    background:     "var(--pri)",
                    border:         "2px solid #fff",
                    display:        "flex",
                    alignItems:     "center",
                    justifyContent: "center",
                  }}>
                    <svg width="7" height="7" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
                      <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
                    </svg>
                  </div>
                </div>

                <button className="btn btn-sm nav-logout-btn" onClick={signOutUser}>Log Out</button>
              </>
            )}
          </div>
        </div>
      </nav>

      {/* Profile Modal */}
      {showProfile && (
        <ProfileModal onClose={() => setShowProfile(false)} />
      )}
    </>
  );
}