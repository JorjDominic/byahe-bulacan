import Stars from "./Stars";

export default function SpotCard({ spot, onClick }) {
  return (
    <div className="spot-card" onClick={onClick}>

      {/* ── Image or emoji fallback ───────────────────────── */}
      <div className="spot-img" style={{ background: spot.bg, position: "relative", overflow: "hidden" }}>
        {spot.imageUrl ? (
          <img
            src={spot.imageUrl}
            alt={spot.name}
            style={{
              width:      "100%",
              height:     "100%",
              objectFit:  "cover",
              display:    "block",
            }}
          />
        ) : (
          <span style={{ fontSize: "2.5rem" }}>{spot.emoji}</span>
        )}
        {spot.badge && (
          <span className="spot-badge" style={{ position: "absolute", top: 8, right: 8 }}>
            {spot.badge}
          </span>
        )}
      </div>

      {/* ── Spot info ─────────────────────────────────────── */}
      <div className="spot-info">
        <h4>{spot.name}</h4>
        <div className="spot-loc">📍 {spot.municipality}, Bulacan</div>
        <div className="stars-row">
          <Stars rating={spot.rating || 0} />
          <span className="review-count">({spot.reviews || 0})</span>
        </div>
        <div className="spot-fee">
          {spot.fee === "Free" ? "Free entrance" : spot.fee + " entrance fee"}
        </div>
        <div style={{
          display:      "inline-block",
          marginTop:    "0.35rem",
          fontSize:     "0.72rem",
          padding:      "2px 8px",
          borderRadius: 20,
          background:   "var(--bg-secondary)",
          color:        "var(--muted)",
          fontWeight:   500,
        }}>
          {spot.category}
        </div>
      </div>
    </div>
  );
}